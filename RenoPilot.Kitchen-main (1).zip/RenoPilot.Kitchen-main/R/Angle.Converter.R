#' Angle Converter
#'
#' @description
#' Services used to convert from degrees to radians and visa versa:
#' 
#' @usage NULL
#' @return A `list` of converters:
#' - `[['degreesToRadians']]()` 
#' - `[['radiansToDegrees']]()`
Angle.Converter <- \() {
  converters <- list()
  #' @description
  #' - `[['degreesToRadians']]()` convert from degrees to radians.
  #' @param degrees as a `numeric` value.
  #' @return radians as a `numeric` value. 
  converters[['degreesToRadians']] <- \(degrees) {
    degrees * pi / 180
  }
  #' @description
  #' - `[['radiansToDegrees']]()` convert from radians to degrees.
  #' @param radians as a `numeric` value.
  #' @return degrees as a `numeric` value.
  converters[['radiansToDegrees']] <- \(radians) {
    radians * 180 / pi
  }
  return(converters)
}