#Import shiny library
library(shiny)

# All controllers should take an input, output and the model (as the ID is required to bind to the UI)
Benchtop.Controller <- \(input, output, model){
    controller <- list()
    id <- model[["id"]]
    ns <- NS(id)

#Update the x, y positions, height and width, finish and type according to user input 
    controller[["UPDATE"]] <- reactive({
        x <- as.numeric(input[[ns(".x")]])
        y <- as.numeric(input[[ns(".y")]])
        h <- as.numeric(input[[ns(".h")]])
        w <- as.numeric(input[[ns(".w")]])
        finish <- input[[ns(".finish")]]
        type <- input[[ns(".type")]]

        model[["x"]] <- x
        model[["y"]] <- y
        model[["height"]] <- h
        model[["width"]] <- w
        model[["specifications"]] <- list(finish = finish, type = type)
    })

#Triggers UPDATE function if there are any changes to these events observed
    observeEvent(
        c(
            input[[ns(".x")]],
            input[[ns(".y")]],
            input[[ns(".w")]],
            input[[ns(".h")]],
            input[[ns(".finish")]],
            input[[ns(".type")]]
        ),
        {
            controller[["UPDATE"]]()
        },
        ignoreInit = TRUE
    )

    return(controller)
}
