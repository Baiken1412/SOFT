# Read all finishes from a CSV file to a dataframe.
benchtopFinishesDF <- read.csv("data/benchtop_finishes.csv")

# Initialise lists to store the attributes of a benchtop
benchtopFinishes <- list()
benchtopTypes <- list()

# Method to extract each column from the data frame of benchtop finishes
setUpBenchtopFinishes <- function() {
    finishes <- benchtopFinishesDF[, c(1)]
    colour <- benchtopFinishesDF[, c(2)]
    rgb <- benchtopFinishesDF[, c(3)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- colour[i]
        value <- rgb[i]
        benchtopFinishes[[key]] <- value
    }
    return(benchtopFinishes)
}

benchtopFinishes <- setUpBenchtopFinishes()

# Return a list of strings benchtop finishes
getBenchtopFinishes <- function() {
    return(names(benchtopFinishes))
}

# Method to attract each column from the data frame of benchtop types
setUpBenchtopTypes <- function() {
    finishes <- benchtopFinishesDF[, c(1)]
    colour <- benchtopFinishesDF[, c(2)]
    rgb <- benchtopFinishesDF[, c(3)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Type, Value --> RGB)
    for (i in 1:length(finishes)) {
        benchtopTypes <- append(benchtopTypes, finishes[i])
    }

    return(benchtopTypes)
}

benchtopTypes <- setUpBenchtopTypes()

# Return a list of unique benchtop types to view on the UI
getBenchtopTypes <- function() {
    return(unique(benchtopTypes))
}

Benchtop.Designer <- function(model) {

    # Construct basic shapes for benchtop
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract attributes for benchtop
    colour <- benchtopFinishes[[specifications[["finish"]]]]
    type <- specifications[["type"]]

    # Render benchtop with respect to the coordinates of the plot and specifications chosen from the UI.
    benchtop <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    benchtop[["x"]] <- benchtop[["x"]] + x
    benchtop[["y"]] <- benchtop[["y"]] + y

    return(list(
        list(coordinates = benchtop, colour = colour)
    ))
}
