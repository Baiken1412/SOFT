# Position
# x: int
# y: int

# Dimensions
# width: int
# height: int

# Specifications
# finish: string
# type: string

# The Model in the MVC architecture that holds the attributes of a component
Benchtop.Model <- \(
     specifications,
     x = 0,
     y = 0,
     width = 800,
     height = 20
) reactiveValues(
     id = uuid::UUIDgenerate(), # All models MUST have this
     type = "Benchtop", # ALL models MUST have this
     x = x,
     y = y,
     width = width,
     height = height,
     specifications = specifications
)
