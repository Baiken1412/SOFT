#Loads data from Benchtop.Designer class which contains functions for getting different finishes
source("R/Benchtop.Designer.R")

Benchtop.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added option for benchtop height and width to follow industry standards.
            # User will have the option select benchtop thickness and length from list of already specified.
            selectInput(ns(".type"), "Select Benchtop Type", getBenchtopTypes(), selected = specs[["type"]]), # nolint: line_length_linter.
            selectInput(ns(".finish"), "Select Benchtop Finish", getBenchtopFinishes(), selected = specs[["finish"]]), # nolint: line_length_linter.
            selectInput(ns(".h"), "Thickness (mm)", c(20, 40, 60, 80, 100), selected = h),
            selectInput(ns(".w"), "Length (mm)", c(800, 850, 900, 950, 1000, 1050, 1100, 1200, 1250, 1300, 1350, 1400, 1450, 1500), selected = w),
            
            #Slider to move the benchtop left and right
            sliderInput(ns(".x"), "Move Benchtop Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),
            #Slider to move the benchtop up and down
            sliderInput(ns(".y"), "Move Benchtop Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
