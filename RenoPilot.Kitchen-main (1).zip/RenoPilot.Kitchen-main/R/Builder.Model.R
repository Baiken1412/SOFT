Builder.Model <- \(){
    controller <- list()

    model <- reactiveValues(id = uuid::UUIDgenerate())

    controller[["setType"]] <- \(type){
        model[["type"]] <- type
        return(controller)
    }

    controller[["setX"]] <- \(x){
        model[["x"]] <- x
        return(controller)
    }

    controller[["setY"]] <- \(y){
        model[["y"]] <- y
        return(controller)
    }

    controller[["setWidth"]] <- \(w) {
        model[["width"]] <- w
        return(controller)
    }

    controller[["setHeight"]] <- \(h) {
        model[["height"]] <- h
        return(controller)
    }

    controller[["setSpecs"]] <- \(specs) {
        model[["specifications"]] <- specs
        return(controller)
    }



    controller[["build"]] <- \(){
        return(model)
    }

    return(controller)
}


# Builder.Builder <- \() {

# }
