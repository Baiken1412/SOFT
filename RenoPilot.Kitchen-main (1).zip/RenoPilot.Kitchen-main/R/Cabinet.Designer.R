# Read all finishes from a CSV file to a dataframe.
cabinetTypes <- c("Floor", "Wall Mounted")
cabinetFinishesDF <- read.csv("data/door_finishes.csv")
cabinetDesignsDF <- read.csv("data/cabinet_cupboard_designs.csv")

# Initialise lists to store the attributes of a cabinet
cabinetDesigns <- list()
cabinetFinishes <- list()

# Method to extract each column from the data frame of cabinet finishes
setUpCabinetFinishes <- function() {
    finishes <- cabinetFinishesDF[, c(1)]
    rgb <- cabinetFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        cabinetFinishes[[key]] <- value
    }

    return(cabinetFinishes)
}

cabinetFinishes <- setUpCabinetFinishes()

# Return a list of strings cabinet finishes
getCabinetFinishes <- function() {
    return(names(cabinetFinishes))
}

# Return a list of strings cabinet types
getCabinetTypes <- function() {
    return(cabinetTypes)
}

# Return a list of strings cabinet designs
getCabinetDesigns <- function() {
    cabinetDesigns <- c(cabinetDesignsDF[["Design"]])
    return(cabinetDesigns)
}

Cabinet.Designer <- function(model) {
    
    # Construct basic shapes for cabinet
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]
    
    # Extract attributes for cabinet
    colour <- cabinetFinishes[[specifications[["finish"]]]]
    type <- specifications[["type"]]
    design <- specifications[["design"]]

    # Render benchtop with respect to the coordinates of the plot and specifications chosen from the UI.
    cabinetR <- shapeUtility[["Rectangle"]](list(width = width / 2, height = height))
    cabinetR[["x"]] <- cabinetR[["x"]] + x
    cabinetR[["y"]] <- cabinetR[["y"]] + y


    cabinetL <- shapeUtility[["Rectangle"]](list(width = width / 2, height = height))
    cabinetL[["x"]] <- cabinetL[["x"]] + x + width / 2
    cabinetL[["y"]] <- cabinetL[["y"]] + y

    rectKnobR <- shapeUtility[["Rectangle"]](list("width" = 10, "height" = 200))
    rectKnobL <- shapeUtility[["Rectangle"]](list("width" = 10, "height" = 200))
    
    rectKnobR[["x"]] <- rectKnobR[["x"]] + x + 0.7 * width
    rectKnobL[["x"]] <- rectKnobL[["x"]] + x + 0.3 * width

    # Render type of cabinet depending on UI input.
    if (type == "Floor") {
        rectKnobR[["y"]] <- rectKnobR[["y"]] + (2 * y + (0.7) * height) / 2
        rectKnobL[["y"]] <- rectKnobL[["y"]] + (2 * y + (0.7) * height) / 2
    }

    if (type == "Wall Mounted") {
        rectKnobR[["y"]] <- rectKnobR[["y"]] + (2 * y + (0.4) * height) / 2
        rectKnobL[["y"]] <- rectKnobL[["y"]] + (2 * y + (0.4) * height) / 2
    }

    # Render design of cabinet depending on UI input.
    if (design == "Cora") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = width/2.5, "height" = height/1.045))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.05 * width)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.025 * height)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = width/2.5, "height" = height/1.045))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.55 * width)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.025 * height)

        return(
            list(
                list(coordinates = cabinetL, colour = colour),
                list(coordinates = cabinetR, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobL, colour = colour),
                list(coordinates = rectKnobR, colour = colour)
            )
        )
    }

    if (design == "Sienna") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = width/3, "height" = height/1.045))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.07 * width)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.02 * height)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = width/3, "height" = height/1.045))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.58 * width)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.02 * height)
        return(
            list(
                list(coordinates = cabinetL, colour = colour),
                list(coordinates = cabinetR, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobL, colour = colour),
                list(coordinates = rectKnobR, colour = colour)
            )
        )
    }

    if (design == "Sienna IV") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = width/3.5, "height" = height/1.045))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.07 * width)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.02 * height)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = width/3.5, "height" = height/1.045))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.63 * width)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.02 * height)
        return(
            list(
                list(coordinates = cabinetL, colour = colour),
                list(coordinates = cabinetR, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobL, colour = colour),
                list(coordinates = rectKnobR, colour = colour)
            )
        )
    }

    ## No designs here, so returning the default door.
    if (design == "Tiffany") {
        return(
            list(
                list(coordinates = cabinetL, colour = colour),
                list(coordinates = cabinetR, colour = colour),
                list(coordinates = rectKnobL, colour = colour),
                list(coordinates = rectKnobR, colour = colour)
            )
        )
    }
}
