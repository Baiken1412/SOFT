#Loads data from Cabinet.Designer class which contains functions for getting different finishes
source("R/Cabinet.Designer.R")
Cabinet.View <- function(model) {
    id <- model[["id"]]
    h <- model[["height"]]
    w <- model[["width"]]
    x <- model[["x"]]
    y <- model[["y"]]
    specs <- model[["specifications"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added option for non-adjustable cabinet height and width to follow industry standards.
            # User will have the option select cabinet height and width from list of specified dimensions.
            selectInput(ns(".type"), "Cabinet Type", getCabinetTypes(), selected = specs[["type"]]), # nolint: line_length_linter.
            selectInput(ns(".finish"), "Finish on Cabinet", getCabinetFinishes(), selected = specs[["finish"]]),
            selectInput(ns(".design"), "Design on Cabinet", getCabinetDesigns(), selected = specs[["design"]]),
            selectInput(ns(".dim"), "Cabinet Dimensions in Millimetres (H x W)", c("720 x 150", "720 x 300", "720 x 450", "720 x 600", "720 x 750", "720 x 900", "720 x 1050"), selected = dim), # nolint: line_length_linter.
            #Slider to move cabinet left and right
            sliderInput(ns(".x"), "Move Cabinet Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),
            #Slider to move cabinet up and down
            sliderInput(ns(".y"), "Move Cabinet Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
