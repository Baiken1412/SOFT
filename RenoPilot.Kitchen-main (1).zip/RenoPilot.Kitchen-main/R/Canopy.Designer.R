# Read all finishes from a CSV file to a dataframe.
canopyFinishesDF <- read.csv("data/canopy_finishes.csv")

# Initialise lists to store the attributes of a canopy
canopyFinishes <- list()

# Method to extract each column from the data frame of canopy finishes
setUpCanopyFinishes <- function() {
    finishes <- canopyFinishesDF[, c(1)]
    rgb <- canopyFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        canopyFinishes[[key]] <- value
    }

    return(canopyFinishes)
}

canopyFinishes <- setUpCanopyFinishes()

# Return a list of strings canopy finishes
getCanopyFinishes <- function() {
    return(names(canopyFinishes))
}

Canopy.Designer <- \(model){
    
    # Construct basic shapes for canopy
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]

    specs <- model[["specifications"]]

    # Extract attributes for canopy
    colour <- canopyFinishes[[specs[["finish"]]]]

    # Draw canopy with constructed shapes onto the UI plot when selected
    topRect <-  shapeUtility[["Rectangle"]](list(width = width * 0.5, height = height * 0.25))
    topRect[["x"]] <- topRect[["x"]] + x + 0.25 * width
    topRect[["y"]] <- topRect[["y"]] + y + 0.75 * height

    middleTrapezium <- shapeUtility[["Trapezoid"]](list(bottom = width, top = width * 0.5, height = height * 0.5))
    middleTrapezium[["x"]] <- middleTrapezium[["x"]] + x
    middleTrapezium[["y"]] <- middleTrapezium[["y"]] + y + 0.25 * height

    bottomUpperRect <- shapeUtility[["Rectangle"]](list(width = width, height = height * 0.2))
    bottomUpperRect[["x"]] <- bottomUpperRect[["x"]] + x
    bottomUpperRect[["y"]] <- bottomUpperRect[["y"]] + y + 0.05 * height

    bottomLowerRect <- shapeUtility[["Rectangle"]](list(width = width, height = height * 0.05))
    bottomLowerRect[["x"]] <- bottomLowerRect[["x"]] + x
    bottomLowerRect[["y"]] <- bottomLowerRect[["y"]] + y
    
    return(
        list(
            list(coordinates = topRect, colour = colour),
            list(coordinates = middleTrapezium, colour = colour),
            list(coordinates = bottomLowerRect, colour = colour),
            list(coordinates = bottomUpperRect, colour = colour)
        )
    )

}