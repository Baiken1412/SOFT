# Position
# x: int
# y: int

# Dimensions
# width: int
# height: int

# Specifications
# finish: string

# The Model in the MVC architecture that holds the attributes of a component
Canopy.Model <- \(specifications) reactiveValues(
     id = uuid::UUIDgenerate(), #All models MUST have this
     type = "Canopy", # ALL models MUST have this
     x = 0,
     y = 0,
     width = 600,
     height = 400,
     specifications = specifications
)
