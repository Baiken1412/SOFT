#Loads data from Canopy.Designer class which contains functions for getting different finishes
source("R/Canopy.Designer.R")

Canopy.View <- \(model){
    spec <- model[["specifications"]]
    id <- model[["id"]]
    w <- model[["width"]]
    h <- model[["height"]]
    ns <- NS(id)
    return(
        # Specifies height, width and finish from list 
        tagList(
            selectInput(ns(".h"), "Height", c(200, 300, 400), selected = model[["height"]]),
            selectInput(ns(".w"), "Width", c(600, 900), selected = model[["width"]]),
            selectInput(ns(".finish"), "Metal Finish", getCanopyFinishes(), selected = spec[["finish"]]),
            #Slider to move canopy left and right
            sliderInput(ns(".x"), "Horizontal Position", value = model[["x"]], min = 0, max = kitchenDimensions[["width"]] - w),
            #Slider to move canopy up and down
            sliderInput(ns(".y"), "Vertical Position", value = model[["y"]], min = 0, max = kitchenDimensions[["height"]] - h)
        )
    )
}
