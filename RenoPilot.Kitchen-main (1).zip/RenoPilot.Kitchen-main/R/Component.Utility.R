#' @importFrom graphics polygon
Component.Utility <- \(){
  geometry.utility <- Geometry.Utility()

  utilities <- list()
  utilities[['getMinY']]      <- \(shapes) {
    shapes |> lapply(\(shape) shape[['y']] |> min()) |> unlist() |> min() 
  }
  utilities[['getMaxY']]      <- \(shapes) { 
    shapes |> lapply(\(shape) shape[['y']] |> max()) |> unlist() |> max() 
  }
  utilities[['getHeight']]    <- \(shapes) {
    if (shapes |> length() == 0) return(0)
    (shapes |> utilities[['getMaxY']]()) - (shapes |> utilities[['getMinY']]())
  }
  utilities[['shrinkHeight']] <- \(shapes, floor, amount) {
    shapes |> lapply(\(shape) shape |> geometry.utility[['reduceHeight']](floor, amount))
  }
  utilities[['translate']]    <- \(component, offset) {
    component |> lapply(\(shape) 
      shape |> lapply(\(coordinates) 
        coordinates |> geometry.utility[['translate']](offset)))
  }
  utilities[['Plot']]         <- \(component, specifications) {
    component |> lapply(\(shape) 
      shape |> lapply(\(coordinates) 
        coordinates |> polygon(col = specifications[['color']]))) |> invisible()
  }
  return(utilities)
}