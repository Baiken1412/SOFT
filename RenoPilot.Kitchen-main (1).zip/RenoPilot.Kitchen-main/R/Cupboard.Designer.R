# Read all finishes from a CSV file to a dataframe.
cupboardFinishesDF <- read.csv("data/door_finishes.csv")
cupboardDesignsDF <- read.csv("data/cabinet_cupboard_designs.csv")

# Initialise lists to store the attributes of a cupboard
cupboardFinishes <- list()
cupboardDesigns <- list()

# Method to extract each column from the data frame of cupboard finishes
setUpCupboardFinishes <- function() {
    finishes <- cupboardFinishesDF[, c(1)]
    rgb <- cupboardFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        cupboardFinishes[[key]] <- value
    }

    return(cupboardFinishes)
}

cupboardFinishes <- setUpCupboardFinishes()

# Return a list of strings cupboard finishes
getCupboardFinishes <- function() {
    return(names(cupboardFinishes))
}

# Return a list of strings cupboard designs
getCupboardDesigns <- function() {
    cupboardDesigns <- c(cupboardDesignsDF[["Design"]])
    return(cupboardDesigns)
}

Cupboard.Designer <- function(model) {
    
    # Construct basic shapes for cupboard
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract attributes for cupboard
    colour <- cupboardFinishes[[specifications[["finish"]]]]
    design <- design <- specifications[["design"]]

    # Draw cupboard with constructed shapes onto the UI plot when selected
    cupboardTop <- shapeUtility[["Rectangle"]](list(width = w, height = h / 2))
    cupboardTop[["x"]] <- cupboardTop[["x"]] + x
    cupboardTop[["y"]] <- cupboardTop[["y"]] + y + (h / 2)

    cupboardBot <- shapeUtility[["Rectangle"]](list(width = w, height = h / 2))
    cupboardBot[["x"]] <- cupboardBot[["x"]] + x
    cupboardBot[["y"]] <- cupboardBot[["y"]] + y

    rectKnobU <- shapeUtility[["Rectangle"]](list(width = w / 4, height = 5))
    rectKnobU[["x"]] <- rectKnobU[["x"]] + x + w / 2 - w / 8
    rectKnobU[["y"]] <- rectKnobU[["y"]] + y + 0.9 * h

    rectKnobB <- shapeUtility[["Rectangle"]](list(width = w / 4, height = 5))
    rectKnobB[["x"]] <- rectKnobB[["x"]] + x + w / 2 - w / 8
    rectKnobB[["y"]] <- rectKnobB[["y"]] + y + (h / 2) - 0.1 * h

    # Render design of cupboard depending on UI input.
    if (design == "Cora") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = w/1.09, "height" = h/2.5))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.04 * w)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.55 * h)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = w/1.09, "height" = h/2.5))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.04 * w)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.05 * h)

        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }

    if (design == "Sienna") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = w/1.2, "height" = h/2.5))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.08 * w)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.55 * h)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = w/1.2, "height" = h/2.5))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.08 * w)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.05 * h)
        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }

    if (design == "Sienna IV") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = w/1.1, "height" = h/2.5))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.05 * w)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.55 * h)

        rect_R <- shapeUtility[["Rectangle"]](list("width" = w/1.1, "height" = h/2.5))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.05 * w)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.05 * h)
        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }

    ## No designs here, so returning the default door.
    if (design == "Tiffany") {
        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }
}
