#Loads data from Cupboard.Designer class which contains functions for getting different finishes
source("R/Cupboard.Designer.R")

Cupboard.View <- function(model) {
    id <- model[["id"]]
    h <- model[["height"]]
    w <- model[["width"]]
    x <- model[["x"]]
    y <- model[["y"]]
    specs <- model[["specifications"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            selectInput("cupboard.type", "Cupboard Type", c("Shaker", "Sliding", "Wall Mounted")), # nolint: line_length_linter.
            selectInput(ns(".finish"), "Finish on Cupboard", getCupboardFinishes(), selected = specs[["finish"]]),
            selectInput(ns(".design"), "Design on Cupboard", getCupboardDesigns(), selected = specs[["design"]]),
            
            # Added non-adjustable option for cupboard height and width to follow industry standards.
            # User will have the option select a cupboard with fixed dimensions from the dropdown list.
            selectInput(ns(".dim"), "Cupboard Dimensions in Millimetres (H x W)", c("720 x 720", "720 x 300", "720 x 600", "720 x 900"), selected = dim), # nolint: line_length_linter.
            #Slider to move cupboard left and right
            sliderInput(ns(".x"), "Move Cupboard Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),
            #Slider to move cupboard up and down
            sliderInput(ns(".y"), "Move Cupboard Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
