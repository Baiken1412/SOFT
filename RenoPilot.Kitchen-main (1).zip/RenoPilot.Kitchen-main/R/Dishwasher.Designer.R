# Read all finishes from a CSV file to a dataframe.
dishwasherFinishesDF <- read.csv("data/dishwasher_finishes.csv")

# Initialise lists to store the attributes of a dishwasher
dishwasherFinishes <- list()


# Method to extract each column from the data frame of dishwasher finishes
setUpDishwasherFinishes <- function() {
    finishes <- dishwasherFinishesDF[, c(1)]
    rgb <- dishwasherFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        dishwasherFinishes[[key]] <- value
    }

    return(dishwasherFinishes)
}

dishwasherFinishes <- setUpDishwasherFinishes()

# Return a list of strings dishwasher finishes
getDishwasherFinishes <- function() {
    return(names(dishwasherFinishes))
}

# Return a list of strings dishwasher types 
getDishwasherTypes <- function() {
    return(dishwasherTypes)
}

Dishwasher.Designer <- function(model) {
    
    # Construct basic shapes for dishwasher
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract attributes for dishwasher
    colour <- dishwasherFinishes[[specifications[["finish"]]]]

    # Draw dishwasher with constructed shapes onto the UI plot when selected
    dishwasher <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    dishwasher[["x"]] <- dishwasher[["x"]] + x
    dishwasher[["y"]] <- dishwasher[["y"]] + y

    handle <- shapeUtility[["Rectangle"]](list("width" = width * 0.65, "height" = height * 0.05))
    handle[["x"]] <- handle[["x"]] + x + ((0.2) * width)
    handle[["y"]] <- handle[["y"]] + (y + (height - 100))

    bottom <- shapeUtility[["Rectangle"]](list("width" = width * 1, "height" = height * 0.2))
    bottom[["x"]] <- bottom[["x"]] + x + ((0) * width)
    bottom[["y"]] <- bottom[["y"]] + (y + (height - height))

    return(list(
        list(coordinates = dishwasher, colour = colour),
        list(coordinates = bottom, colour = "#C0C0C0"),
        list(coordinates = handle, colour = "#C0C0C0")
    ))
}
