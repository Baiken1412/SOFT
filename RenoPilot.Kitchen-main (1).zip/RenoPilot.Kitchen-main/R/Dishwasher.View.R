#Loads data from Dishwasher.Designer class which contains functions for getting different finishes
source("R/Dishwasher.Designer.R")

Dishwasher.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added non-adjustable option for Dishwasher height and width to follow industry standards.
            # User will have the option select a Dishwasher with fixed dimensions from the dropdown list.
            selectInput(ns(".finish"), "Select Dishwasher Finish", getDishwasherFinishes(), selected = specs[["finish"]]), # nolint: line_length_linter.
            selectInput(ns(".dim"), "Dishwasher Dimensions in Millimetres (H x W)", c("470 x 600", "720 x 600"), selected = dim), # nolint: line_length_linter.
            
            #Slider to move dishwasher left and right
            sliderInput(ns(".x"), "Move Dishwasher Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),

            #Slider to move dishwasher up and down
            sliderInput(ns(".y"), "Move Dishwasher Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
