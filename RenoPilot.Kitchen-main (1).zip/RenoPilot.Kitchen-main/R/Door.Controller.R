#Import shiny library
library(shiny)

# All controllers should take an input, output and the model (as the ID is required to bind to the UI)
Door.Controller <- \(input, output, model){
    controller <- list()
    id <- model[["id"]]
    ns <- NS(id)

    retrieveDoorDim <- function(dim) {
        dimStr <- dim
        dimList <- strsplit(dimStr[1], " x ")
        doorH <- as.integer(dimList[[1]][1])
        doorW <- as.integer(dimList[[1]][2])
        return(c(
            height = doorH,
            width = doorW
        ))
    }

#Update the x, y positions, height and width, finish and design according to user input 
    controller[["UPDATE"]] <- reactive({
        x <- as.numeric(input[[ns(".x")]])
        y <- as.numeric(input[[ns(".y")]])
        dimStr <- input[[ns(".dim")]]
        dimList <- retrieveDoorDim(dimStr)
        height <- dimList[["height"]]
        width <- dimList[["width"]]
        finish <- input[[ns(".finish")]]
        design <- input[[ns(".design")]]

        model[["x"]] <- x
        model[["y"]] <- y
        model[["width"]] <- width
        model[["height"]] <- height
        model[["specifications"]] <- list(finish = finish, design = design)
    })

#Triggers UPDATE function if there are any changes to these events observed
    observeEvent(
        c(
            input[[ns(".x")]],
            input[[ns(".y")]],
            input[[ns(".dim")]],
            input[[ns(".finish")]],
            input[[ns(".design")]]
        ),
        {
            controller[["UPDATE"]]()
        },
        ignoreInit = TRUE
    )

    return(controller)
}
