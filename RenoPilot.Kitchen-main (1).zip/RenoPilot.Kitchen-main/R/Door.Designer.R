# Read all finishes from a CSV file to a dataframe.
doorFinishesDF <- read.csv("data/door_finishes.csv")
doorDesignsDF <- read.csv("data/door_designs.csv")

# Initialise lists to store the attributes of a door
doorFinishes <- list()
doorDesigns <- list()

# Method to extract each column from the data frame of door finishes
setUpDoorFinishes <- function() {
    finishes <- doorFinishesDF[, c(1)]
    rgb <- doorFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        doorFinishes[[key]] <- value
    }

    return(doorFinishes)
}

doorFinishes <- setUpDoorFinishes()

# Return a list of strings door finishes
getDoorFinishes <- function() {
    return(names(doorFinishes))
}

# Return a list of strings door designs
getDoorDesigns <- function() {
    doorDesigns <- c(doorDesignsDF[["Design"]])
    return(doorDesigns)
}

Door.Designer <- \(model){
    
    # Construct basic shapes for door
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]

    specs <- model[["specifications"]]

    # Extract attributes for door
    colour <- doorFinishes[[specs[["finish"]]]]
    design <- specs[["design"]]

    # Draw door with constructed shapes onto the UI plot when selected
    doorPanel <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    doorPanel[["x"]] <- doorPanel[["x"]] + x
    doorPanel[["y"]] <- doorPanel[["y"]] + y

    squareKnob <- shapeUtility[["Square"]](list("size" = 20))
    squareKnob[["x"]] <- squareKnob[["x"]] + x + 0.8 * width
    squareKnob[["y"]] <- squareKnob[["y"]] + (2 * y + height) / 2

    # Render design of cupboard depending on UI input.
    if (design == "Cora") {
        rect_one <- shapeUtility[["Rectangle"]](list("width" = width/1.3, "height" = height/1.055))
        rect_one[["x"]] <- rect_one[["x"]]+ x + (0.12 * width)
        rect_one[["y"]] <- rect_one[["y"]] + y + (0.025 * height)

        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = rect_one, colour = colour),
                list(coordinates = squareKnob, colour = colour)
            )
        )
    }

    if (design == "Sienna") {
        rect_one <- shapeUtility[["Rectangle"]](list("width" = width/2, "height" = height/1.1))
        rect_one[["x"]] <- rect_one[["x"]]+ x + (0.25 * width)
        rect_one[["y"]] <- rect_one[["y"]] + y + (0.045 * height)

        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = rect_one, colour = colour),
                list(coordinates = squareKnob, colour = colour)
            )
        )
    }

    if (design == "Sienna IV") {
        rect_one <- shapeUtility[["Rectangle"]](list("width" = width/1.5, "height" = height/1.065))
        rect_one[["x"]] <- rect_one[["x"]]+ x + (0.15 * width)
        rect_one[["y"]] <- rect_one[["y"]] + y + (0.025 * height)
        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = rect_one, colour = colour),
                list(coordinates = squareKnob, colour = colour)
            )
        )
    }

    if (design == "Verity") {
        rect_one <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_one[["x"]] <- rect_one[["x"]]+ x + width
        rect_one[["y"]] <- rect_one[["y"]] + y

        rect_two <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_two[["x"]] <- rect_two[["x"]] + x + width + (width/12)
        rect_two[["y"]] <- rect_two[["y"]] + y

        rect_three <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_three[["x"]] <- rect_three[["x"]] + x +  width + (width/6)
        rect_three[["y"]] <- rect_three[["y"]] + y

        rect_four <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_four[["x"]] <- rect_four[["x"]] + x 
        rect_four[["y"]] <- rect_four[["y"]] + y

        rect_five <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_five[["x"]] <- rect_five[["x"]] + x + (width/12)
        rect_five[["y"]] <- rect_five[["y"]] + y

        rect_six <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_six[["x"]] <- rect_six[["x"]] + x + (width/6)
        rect_six[["y"]] <- rect_six[["y"]] + y

        rect_seven <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_seven[["x"]] <- rect_seven[["x"]] + x + (width/3)
        rect_seven[["y"]] <- rect_seven[["y"]] + y

        rect_eight <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_eight[["x"]] <- rect_eight[["x"]] + x + (width/6) + (width/3)
        rect_eight[["y"]] <- rect_eight[["y"]]+ y

        rect_nine <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_nine[["x"]] <- rect_nine[["x"]]  + x + (width/6) + (width/3) + (width/3)
        rect_nine[["y"]] <- rect_nine[["y"]] + y

        rect_ten <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_ten[["x"]] <- rect_ten[["x"]]  + x + (width/6) + (width/1.5)
        rect_ten[["y"]] <- rect_ten[["y"]] + y

        rect_eleven <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_eleven[["x"]] <- rect_eleven[["x"]] + x + (width/1.5) + (width/12)
        rect_eleven[["y"]] <- rect_eleven[["y"]] + y

        rect_twelve <- shapeUtility[["Rectangle"]](list("width" = width / 12, "height" = height))
        rect_twelve[["x"]] <- rect_twelve[["x"]]+ x + ((7*width)/12)
        rect_twelve[["y"]] <- rect_twelve[["y"]] + y
        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = rect_one, colour = colour),
                list(coordinates = rect_two, colour = colour),
                list(coordinates = rect_three, colour = colour),
                list(coordinates = rect_four, colour = colour),
                list(coordinates = rect_five, colour = colour),
                list(coordinates = rect_six, colour = colour),
                list(coordinates = rect_seven, colour = colour),
                list(coordinates = rect_eight, colour = colour),
                list(coordinates = rect_nine, colour = colour),
                list(coordinates = rect_ten, colour = colour),
                list(coordinates = rect_eleven, colour = colour),
                list(coordinates = rect_twelve, colour = colour),
                list(coordinates = squareKnob, colour = "#605f5c")
            )
        )
    }

    if (design == "Vera") {
        rect_one <- shapeUtility[["Rectangle"]](list("width" = width / 6, "height" = height))
        rect_one[["x"]] <- rect_one[["x"]] + x + (width / 6)
        rect_one[["y"]] <- doorPanel[["y"]]

        rect_two <- shapeUtility[["Rectangle"]](list("width" = width / 6, "height" = height))
        rect_two[["x"]] <- rect_two[["x"]] + x + (width/3)
        rect_two[["y"]] <- doorPanel[["y"]]

        rect_three <- shapeUtility[["Rectangle"]](list("width" = width / 6, "height" = height))
        rect_three[["x"]] <- rect_three[["x"]] + x + ((2*width)/3)
        rect_three[["y"]] <- doorPanel[["y"]]

        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = rect_one, colour = colour),
                list(coordinates = rect_two, colour = colour),
                list(coordinates = rect_three, colour = colour),
                list(coordinates = squareKnob, colour = "#605f5c")
            )
        )
    }

    ## No designs here, so returning the default door.
    if (design == "Tiffany") {
        return(
            list(
                list(coordinates = doorPanel, colour = colour),
                list(coordinates = squareKnob, colour = colour)
            )
        )
    }
}
