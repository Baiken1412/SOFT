#Loads data from Dishwasher.Designer class which contains functions for getting different finishes
source("R/Door.Designer.R")

#Import shiny library
library(shiny)

Door.View <- \(model){
    spec <- model[["specifications"]]
    id <- model[["id"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added non-adjustable option for Door height and width to follow industry standards.
            # User will have the option select a Door with fixed dimensions from the dropdown list.
            selectInput(ns(".dim"), "Door Dimensions in Millimetres (H x W)", c("720 x 150", "720 x 300", "720 x 450", "720 x 600", "720 x 750", "720 x 900", "720 x 1050"), selected = dim), # nolint: line_length_linter.
            selectInput(ns(".design"), "Design on Door", getDoorDesigns(), selected = spec[["design"]]),
            selectInput(ns(".finish"), "Finish on Door", getDoorFinishes(), selected = spec[["finish"]]),
            
            #Slider to move door left and right
            sliderInput(ns(".x"), "Horizontal Position", value = model[["x"]], min = 0, max = kitchenDimensions[["width"]] - w),
            
            #Slider to move door up and down
            sliderInput(ns(".y"), "Vertical Position", value = model[["y"]], min = 0, max = kitchenDimensions[["height"]] - h),
        )
    )
}
