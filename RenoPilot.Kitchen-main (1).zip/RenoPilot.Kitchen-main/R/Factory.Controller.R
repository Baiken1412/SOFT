#Factory Controller
#
#This module provides a Factory Controller to manage each type of Kitchen Component
#
#New Controllers can be added and there is a method to get the specific controller for the type of component

Factory.Controller <- \(){
    controllers <- list()
    #Adding new Controllers for all different Kitchen Components
    controllers[["Door"]] <- Door.Controller
    controllers[["Cabinet"]] <- Cabinet.Controller
    controllers[["Panel"]] <- Panel.Controller
    controllers[["Oven"]] <- Oven.Controller
    controllers[["Dishwasher"]] <- Dishwasher.Controller
    controllers[["Cupboard"]] <-Cupboard.Controller
    controllers[["Pantry"]] <- Pantry.Controller
    controllers[["Benchtop"]] <- Benchtop.Controller
    controllers[["Tap"]] <- Tap.Controller
    controllers[["Fridge"]] <- Fridge.Controller
    controllers[["Canopy"]] <- Canopy.Controller
    controllers[["Microwave"]] <- Microwave.Controller

    #Method to check if the type of component exists in the list and return the Kitchen component
    factory <- \(type){
        if (!exists(type, where = controllers)) {
            #If the type does not exist, raise an error
            stop(paste(type, ".Controller has not been added to Factory.Controller.R or does not exist", sep = ""))
        }
        #Else return the corresponding Controller 'type' from the list 
        return(controllers[[type]])
    }
    #Returning factory function 
    return(factory)
}