#Factory Designer
#
#This module provides a Factory Designer to manage each type of Kitchen Component
#
#New Designers can be added and there is a method to get the specific Designer for the type of component

Factory.Designer <- \(){
    designers <- list()
    #Adding new Designers for all different Kitchen Components
    designers[["Door"]] <- Door.Designer
    designers[["Panel"]] <- Panel.Designer
    designers[["Cabinet"]] <- Cabinet.Designer
    designers[["Oven"]] <- Oven.Designer
    designers[["Dishwasher"]] <- Dishwasher.Designer
    designers[["Canopy"]] <- Canopy.Designer
    designers[["Cupboard"]] <- Cupboard.Designer
    designers[["Pantry"]] <- Pantry.Designer
    designers[["Benchtop"]] <- Benchtop.Designer
    designers[["Tap"]] <- Tap.Designer
    designers[["Microwave"]] <- Microwave.Designer
    designers[["Fridge"]] <- Fridge.Designer

    #Method to check if the type of component exists in the list and return the Kitchen component
    factory <- \(type){
        #If the type does not exist, raise an error
        if (!exists(type, where = designers)) {
            stop(paste(type, ".Designer has not been added to Factory.Designer.R or does not exist", sep = ""))
        }
         #Else return the corresponding Designer 'type' from the list 
        return(designers[[type]])
    }
    #Returning factory function 
    return(factory)
}