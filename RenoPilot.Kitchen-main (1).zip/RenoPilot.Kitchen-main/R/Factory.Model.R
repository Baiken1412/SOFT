#Factory Model
#
#This module provides a Factory Model to manage each type of Kitchen Component
#
#New Models can be added with default values and there is a method to get the specific Model for the type of component


Factory.Model <- \() {
    models <- list()

     #Adding new Models for all different Kitchen Components
     #Default values for finish, type and design are passed
     
    models[["Door"]] <- \(){
        return(Door.Model(
            list(finish = "Alaskan White Gloss", design = "Tiffany")
        ))
    }
    models[["Panel"]] <- \(){
        return(Panel.Model(
            list(finish = "Classic White Matt")
        ))
    }

    models[["Cabinet"]] <- \(){
        return(Cabinet.Model(
            list(finish = "Classic White Matt", type = "Floor", design = "Tiffany")
        ))
    }

    models[["Oven"]] <- \(){
        return(Oven.Model(
            list(finish = "Stainless Steel", type = "Single Door with Cooktop")
        ))
    }


    models[["Pantry"]] <- \(){
        return(Pantry.Model(
            list(finish = "Classic White Matt")
        ))
    }

    models[["Benchtop"]] <- \(){
        return(Benchtop.Model(
            list(finish = "Jura Marble Gloss Quadra", type = "Laminate")
        ))
    }

    models[["Dishwasher"]] <- \(){
        return(Dishwasher.Model(
            list(finish = "Stainless Steel", type = "Free Standing")
        ))
    }

    models[["Tap"]] <- \(){
        return(Tap.Model(
            list(finish = "Stainless Steel")
        ))
    }

    models[["Benchtop"]] <- \(){
        return(Benchtop.Model(
            list(finish = "Jura Marble Gloss Quadra", type = "Laminate")
        ))
    }

    models[["Dishwasher"]] <- \(){
        return(Dishwasher.Model(
            list(finish = "Stainless Steel", type = "Free Standing")
        ))
    }

    models[["Tap"]] <- \(){
        return(Tap.Model(
            list(finish = "Stainless Steel")
        ))
    }

    models[["Canopy"]] <- \(){
        return(Canopy.Model(
            list(finish = "Stainless Steel")
        ))
    }

    models[["Cupboard"]] <- \(){
        return(Cupboard.Model(
            list(finish = "Classic White Matt", design = "Tiffany")
        ))
    }

    models[["Microwave"]] <- \(){
        return(Microwave.Model(
            list(finish = "Stainless Steel", type = "Floor", brand = "Smeg")
        ))
    }


    models[["Fridge"]] <- \() {
        return(Fridge.Model(
            list(finish = "Stainless Steel", type = "Top Freezer")
        ))
    }

    #Method to check if the type of component exists in the list and return the Kitchen component
    factory <- \(type){
        if (!exists(type, where = models)) {
            #If the type does not exist, raise an error
            stop(paste(type, ".Model has not been added to Factory.Model.R or does not exist", sep = ""))
        }
        #Else return the corresponding Model 'type' from the list 
        return(models[[type]]())
    }
    #Returning factory function 
    return(factory)
}
