#Factory View
#
#This module provides a View Factory to manage each type of Kitchen Component
#
#New Views can be added and there is a method to get the specific View for the type of component

Factory.View <- \(){
    views <- list()
     #Adding new Views for all different Kitchen Components

    views[["Door"]] <- Door.View
    views[["Panel"]] <- Panel.View
    views[["Cabinet"]] <- Cabinet.View
    views[["Pantry"]] <- Pantry.View
    views[["Oven"]] <- Oven.View
    views[["Benchtop"]] <- Benchtop.View
    views[["Dishwasher"]] <- Dishwasher.View
    views[["Tap"]] <- Tap.View
    views[["Fridge"]] <- Fridge.View
    views[["Canopy"]] <- Canopy.View
    views[["Cupboard"]] <- Cupboard.View
    views[["Microwave"]] <- Microwave.View

    #Method to check if the type of component exists in the list and return the Kitchen component
    factory <- \(type){
        if (!exists(type, where = views)) {
            #If the type does not exist, raise an error
            stop(paste(type, ".View has not been added to Factory.View.R or does not exist"))
        }
        #Else return the corresponding View 'type' from the list 
        return(views[[type]])
    }
     #Returning factory function 
    return(factory)
}