#' View Controller
#'
#' Controller class that holds multiple components
#'
#'  @param id Namespace of view
#'  @param input the input object of shiny
#'  @param output the output object of shiny
#'  @param models the list models to be formatted
#'  @return list of controllers
Format.Controller <- \(id, input, output, models){
    utility <- Format.Utility()
    ns <- NS(id)
    alignLeftObserver <- observeEvent(input[[ns("align-left")]],
        {
            utility[["align-left"]](models)
        },
        ignoreInit = TRUE
    )

    alignRightObserver <- observeEvent(input[[ns("align-right")]],
        {
            utility[["align-right"]](models)
        },
        ignoreInit = TRUE
    )

    alignTopObserver <- observeEvent(input[[ns("align-top")]],
        {
            utility[["align-top"]](models)
        },
        ignoreInit = TRUE
    )

    alignBottomObserver <- observeEvent(input[[ns("align-bottom")]],
        {
            utility[["align-bottom"]](models)
        },
        ignoreInit = TRUE
    )


    stackHorizontalObserver <- observeEvent(input[[ns("stack-horizontal")]],
        {
            utility[["stack-horizontal"]](models)
        },
        ignoreInit = TRUE,
    )

    stackVerticalObserver <- stackVertical <- observeEvent(input[[ns("stack-vertical")]],
        {
            utility[["stack-vertical"]](models)
        },
        ignoreInit = TRUE
    )

    groupedXObserver <- observeEvent(input[[ns("grouped-x-offset")]],
        {
            utility[["offset-x"]](models, input[[ns("grouped-x-offset")]])
            updateSliderInput(inputId = ns("grouped-x-offset"), value = 0)
        },
        ignoreInit = TRUE
    )

    groupedYObserver <- observeEvent(input[[ns("grouped-y-offset")]],
        {
            utility[["offset-y"]](models, input[[ns("grouped-y-offset")]])
            updateSliderInput(inputId = ns("grouped-y-offset"), value = 0)
        },
        ignoreInit = TRUE
    )

    centerHorizontalObserver <- observeEvent(input[[ns("center-align-horizontal")]],
        {
            utility[["center-y"]](models)
        },
        ignoreInit = TRUE
    )

    centerVerticalObserver <- observeEvent(input[[ns("center-align-vertical")]],
        {
            utility[["center-x"]](models)
        },
        ignoreInit = TRUE
    )

    return(list(
        alignLeftObserver,
        alignRightObserver,
        alignTopObserver,
        alignBottomObserver,
        stackHorizontalObserver,
        stackVerticalObserver,
        groupedXObserver,
        groupedYObserver,
        centerHorizontalObserver,
        centerVerticalObserver
    ))
}
