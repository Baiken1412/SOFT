#' Utility class that modifies the position of multiple components
Format.Utility <- \(){
    utility <- list()

    utility[["align-left"]] <- \(models){
        minX <- sapply(models, \(model){
            model[["x"]]
        }) |> min()
        for (model in models) {
            model[["x"]] <- minX
        }
    }

    utility[["align-right"]] <- \(models){
        maxX <- sapply(models, \(model){
            model[["x"]] + model[["width"]]
        }) |> max()

        for (model in models) {
            model[["x"]] <- maxX - model[["width"]]
        }
    }

    utility[["align-top"]] <- \(models){
        minY <- sapply(models, \(model){
            model[["y"]] + model[["height"]]
        }) |> max()
        for (model in models) {
            model[["y"]] <- minY - model[["height"]]
        }
    }

    utility[["align-bottom"]] <- \(models){
        minY <- sapply(models, \(model){
            model[["y"]]
        }) |> min()
        for (model in models) {
            model[["y"]] <- minY
        }
    }


    utility[["stack-horizontal"]] <- \(models){
        orderedIndexes <- sapply(models, \(model){
            model[["x"]]
        }) |> order()
        orderedModels <- models[orderedIndexes]
        for (i in 2:length(models)) {
            orderedModels[[i]][["x"]] <- orderedModels[[i - 1]][["x"]] + orderedModels[[i - 1]][["width"]]
        }
    }

    utility[["stack-vertical"]] <- \(models){
        orderedIndexes <- sapply(models, \(model){
            model[["y"]]
        }) |> order()
        orderedModels <- models[orderedIndexes]
        for (i in 2:length(models)) {
            orderedModels[[i]][["y"]] <- orderedModels[[i - 1]][["y"]] + orderedModels[[i - 1]][["height"]]
        }
    }

    utility[["offset-x"]] <- \(models, offsetX) {
        for (i in 1:length(models)) {
            models[[i]][["x"]] <- models[[i]][["x"]] + offsetX
        }
    }

    utility[["offset-y"]] <- \(models, offsetY) {
        for (i in 1:length(models)) {
            models[[i]][["y"]] <- models[[i]][["y"]] + offsetY
        }
    }

    utility[["center-y"]] <- \(models, offsetY) {
        avgMidpoint <- sapply(models, \(model){
            model[["y"]] + model[["height"]] / 2
        }) |> mean()
        for (model in models) {
            model[["y"]] <- avgMidpoint - model[["height"]] / 2
        }
    }

    utility[["center-x"]] <- \(models, offsetX) {
        avgMidpointX <- sapply(models, \(model){
            model[["x"]] + model[["width"]] / 2
        }) |> mean()
        for (model in models) {
            model[["x"]] <- avgMidpointX - model[["width"]] / 2
        }
    }

    return(utility)
}
