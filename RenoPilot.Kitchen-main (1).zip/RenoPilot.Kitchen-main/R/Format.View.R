library(shiny)

#' View for formatting multiple components together
Format.View <- \(id){
    ns <- NS(id)

    div(
        h5("Select to align each object", style = "color: black;"),
        div(
            actionButton(ns("align-left"), title = "Align left", label = "", icon = icon("object-align-left", lib = "glyphicon")),
            actionButton(ns("align-right"), title = "Align right", label = "", icon = icon("object-align-right", lib = "glyphicon")),
            actionButton(ns("align-bottom"), title = "Align bottom", label = "", icon = icon("object-align-bottom", lib = "glyphicon")),
            actionButton(ns("align-top"), title = "Align top", label = "", icon = icon("object-align-top", lib = "glyphicon"))
        ),
        h5("Select to stack along each axis", style = "color: black;"),
        div(
            actionButton(ns("stack-horizontal"), title = "Stack Horizontal Left", label = "", icon = icon("object-align-horizontal", lib = "glyphicon")),
            actionButton(ns("stack-vertical"), title = "Stack Vertical Bottom", label = "", icon = icon("object-align-vertical", lib = "glyphicon"))
        ),
        h5("Align to Center"),
        div(
            actionButton(ns("center-align-horizontal"), title = "Center Horizontally", label = "", icon = icon("object-align-horizontal", lib = "glyphicon")),
            actionButton(ns("center-align-vertical"), title = "Center Vertically", label = "", icon = icon("object-align-vertical", lib = "glyphicon"))
        ),
        h5("Move selected objects"),
        div(
            sliderInput(ns("grouped-x-offset"), "Move left or right", -1000, 1000, 0),
            sliderInput(ns("grouped-y-offset"), "Move up or down", -1000, 1000, 0)
        )
    )
}
