#Import shiny library
library(shiny)

# All controllers should take an input, output and the model (as the ID is required to bind to the UI)
Fridge.Controller <- \(input, output, model){
    controller <- list()
    id <- model[["id"]]
    ns <- NS(id)

    retrieveFridgeDim <- function(dim) {
        dimStr <- dim
        dimList <- strsplit(dimStr[1], " x ")
        fridgeH <- as.integer(dimList[[1]][1])
        fridgeW <- as.integer(dimList[[1]][2])
        return(c(
            height = fridgeH,
            width = fridgeW
        ))
    }
#Update the x, y positions, height and width, finish and design according to user input 
    controller[["UPDATE"]] <- reactive({
        x <- as.numeric(input[[ns(".x")]])
        y <- as.numeric(input[[ns(".y")]])
        dimStr <- input[[ns(".dim")]]
        dimList <- retrieveFridgeDim(dimStr)
        height <- dimList[["height"]]
        width <- dimList[["width"]]
        finish <- input[[ns(".finish")]]
        type <- input[[ns(".type")]]

        model[["x"]] <- x
        model[["y"]] <- y
        model[["width"]] <- width
        model[["height"]] <- height
        model[["specifications"]] <- list(finish = finish, type = type)
    })

#Triggers UPDATE function if there are any changes to these events observed
    observeEvent(
        c(
            input[[ns(".x")]],
            input[[ns(".y")]],
            input[[ns(".w")]],
            input[[ns(".h")]],
            input[[ns(".dim")]],
            input[[ns(".finish")]],
            input[[ns(".type")]]
        ),
        {
            controller[["UPDATE"]]()
        },
        ignoreInit = TRUE
    )

    return(controller)
}
