fridgeTypes <- c("Side by Side", "Top Freezer")

# Read all finishes from a CSV file to a dataframe.
fridgeFinishesDF <- read.csv("data/fridge_finishes.csv")

# Initialise lists to store the attributes of a fridge
fridgeFinishes <- list()

# Method to extract each column from the data frame of fridge finishes
setUpFridgeFinishes <- function() {
    finishes <- fridgeFinishesDF[, c(1)]
    rgb <- fridgeFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        fridgeFinishes[[key]] <- value
    }

    return(fridgeFinishes)
}

fridgeFinishes <- setUpFridgeFinishes()

# Return a list of strings fridge finishes
getFridgeFinishes <- function() {
    return(names(fridgeFinishes))
}

# Return a list of strings fridge types
getFridgeTypes <- function() {
    return(fridgeTypes)
}

Fridge.Designer <- function(model) {

    # Construct basic shapes for door
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]

    specifications <- model[["specifications"]]

    # Extract attributes for fridge
    colour <- fridgeFinishes[[specifications[["finish"]]]]
    type <- specifications[["type"]]

    # Render type of fridge depending on UI input.
    if (type == "Top Freezer") {
        fridge <- shapeUtility[["Rectangle"]](list(width = width, height = height))
        fridge[["x"]] <- fridge[["x"]] + x
        fridge[["y"]] <- fridge[["y"]] + y

        freezerDoor <- shapeUtility[["Rectangle"]](list("width" = width, "height" = height * 0.4))
        freezerDoor[["x"]] <- freezerDoor[["x"]] + x
        freezerDoor[["y"]] <- freezerDoor[["y"]] + y + height * 0.6

        freezerKnob <- shapeUtility[["Rectangle"]](list("width" = width * 0.05, "height" = height * 0.2))
        freezerKnob[["x"]] <- freezerKnob[["x"]] + x + (0.85) * width
        freezerKnob[["y"]] <- freezerKnob[["y"]] + y + height * 0.7

        return(list(
            list(coordinates = fridge, colour = colour),
            list(coordinates = freezerDoor, colour = colour),
            list(coordinates = freezerKnob, colour = "#000000")
        ))
    }

    if (type == "Side by Side") {
        fridgeR <- shapeUtility[["Rectangle"]](list(width = width / 2, height = height))
        fridgeR[["x"]] <- fridgeR[["x"]] + x
        fridgeR[["y"]] <- fridgeR[["y"]] + y


        fridgeL <- shapeUtility[["Rectangle"]](list(width = width / 2, height = height))
        fridgeL[["x"]] <- fridgeL[["x"]] + x + width / 2
        fridgeL[["y"]] <- fridgeL[["y"]] + y

        rectKnobR <- shapeUtility[["Rectangle"]](list("width" = 10, "height" = 200))
        rectKnobL <- shapeUtility[["Rectangle"]](list("width" = 10, "height" = 200))

        rectKnobR[["x"]] <- rectKnobR[["x"]] + x + 0.7 * width
        rectKnobL[["x"]] <- rectKnobL[["x"]] + x + 0.3 * width

        rectKnobR[["y"]] <- rectKnobR[["y"]] + y + (height / 2)
        rectKnobL[["y"]] <- rectKnobL[["y"]] + y + (height / 2)

        return(list(
            list(coordinates = fridgeR, colour = colour),
            list(coordinates = fridgeL, colour = colour),
            list(coordinates = rectKnobR, colour = colour),
            list(coordinates = rectKnobL, colour = colour)
        ))
    }
}
