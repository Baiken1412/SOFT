#Import shiny library
library(shiny)

#Loads data from Fridge.Designer class which contains functions for getting different finishes
source("R/Fridge.Designer.R")
Fridge.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added non-adjustable option for fridge height and width to follow industry standards.
            # User will have the option select a fridge with fixed dimensions from the dropdown list.
            selectInput(ns(".finish"), "Select Fridge Finish", getFridgeFinishes(), selected = specs[["finish"]]), # nolint: line_length_linter.
            selectInput(ns(".type"), "Select Fridge Type", getFridgeTypes(), selected = specs[["type"]]), # nolint: line_length_linter.
            selectInput(ns(".dim"), "Fridge Dimensions in Millimetres (H x W)", c("837 x 470", "1756 x 895"), selected = dim), # nolint: line_length_linter.
            
            #Slider for moving fridge left and right
            sliderInput(ns(".x"), "Move Fridge Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),

            #Slider to move fridge up and down
            sliderInput(ns(".y"), "Move Fridge Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
