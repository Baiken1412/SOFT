Geometry.Converter <- \() {
  services <- list()
  services[['polarToCartesian']] <- \(coordinates) {
    data.frame(
      x = (coordinates[['angle']] |> cos()) * coordinates[['radius']],
      y = (coordinates[['angle']] |> sin()) * coordinates[['radius']]
    )
  }
  return(services)
}