Geometry.Utility <- \() {
  utilities <- list()
  utilities[['join']]         <- \(shape.one, shape.two) {
    if (length(shape.two) == 0) {
        return(shape.one)
    }

    shape.one <- shape.one[[1]]
    shape.two <- shape.two[[1]]

    intersection <-
      shape.one |>
        dplyr::mutate(id = 1:dplyr::n()) |>
        dplyr::inner_join(shape.two, by = c('x','y')) |>
        unique()

    intersection.start <- intersection[which.min(intersection[['id']]),3]
    intersection.end   <- intersection[which.max(intersection[['id']]),3]

    start <- shape.one[0:intersection.start,]
    end   <- shape.one[-(0:(intersection.end-1)),]

    addon <- shape.two |> dplyr::anti_join(intersection, by = c('x','y'))

    shape <- list()
    shape[[1]] <-
        start |>
        rbind(addon) |>
        rbind(end)

    return(shape)
  }
  utilities[['translate']]    <- \(shape, offset) {
    shape[['x']] <- shape[['x']] + offset[['x']]
    shape[['y']] <- shape[['y']] + offset[['y']]
    return(shape)
  }
  utilities[['create']]       <- \(shape) {
    shape.generator <- Shape.Generator()

    shape[['Specifications']] |> 
      shape.generator[[shape[['Type']]]]() |> 
      utilities[['translate']](shape[['Offset']])
  }
  utilities[['reduceHeight']] <- \(coordinates, floor, amount) {
      values <- coordinates[['y']] 
      values[values > floor]  <- values[values > floor] - amount
      coordinates[['y']] <- values
      coordinates
   }
  return(utilities)
}