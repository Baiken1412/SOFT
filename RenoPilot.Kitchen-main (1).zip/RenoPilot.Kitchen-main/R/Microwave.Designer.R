microwaveTypes <- c("Floor", "Wall Mounted")

# Read all finishes from a CSV file to a dataframe.
microwaveFinishesDF <- read.csv("data/microwave_finishes.csv")
microwaveBrandsDF <- read.csv("data/microwave_brands.csv")

# Initialise lists to store the attributes of a microwave
microwaveFinishes <- list()
microwaveBrands <- list()

# Method to extract each column from the data frame of microwave finishes
setUpMicrowaveFinishes <- function() {
    finishes <- microwaveFinishesDF[, c(1)]
    rgb <- microwaveFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        microwaveFinishes[[key]] <- value
    }

    return(microwaveFinishes)
}

microwaveFinishes <- setUpMicrowaveFinishes()

# Return a list of strings microwave finishes
getMicrowaveFinishes <- function() {
    return(names(microwaveFinishes))
}

# Return a list of strings microwave types
getMicrowaveTypes <- function() {
    return(microwaveTypes)
}

# Return a list of strings microwave brands
getMicrowaveBrands <- function() {
    return(c(microwaveBrandsDF[["Brand"]]))
}

Microwave.Designer <- function(model) {
    
    # Construct basic shapes for microwave
    shapeUtility <- Shape.Generator()
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract attributes for microwave
    colour <- microwaveFinishes[[specifications[["finish"]]]]
    type <- specifications[["type"]]

    # Draw basic microwave body
    microwave <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    x <- model[["x"]]
    y <- model[["y"]]
    microwave[["x"]] <- microwave[["x"]] + x
    microwave[["y"]] <- microwave[["y"]] + y

    # Render type of microwave depending on UI input
    if (type == "Floor") {
        microwaveMainScreen <- shapeUtility[["Rectangle"]](list("width" = width * 0.5, "height" = height * 0.7))
        microwaveMainScreen[["x"]] <- microwaveMainScreen[["x"]] + x + (0.1) * width
        microwaveMainScreen[["y"]] <- microwaveMainScreen[["y"]] + (y + (height / 7))

        microwaveSmallScreen <- shapeUtility[["Square"]](list("size" = width / 5))
        microwaveSmallScreen[["x"]] <- microwaveSmallScreen[["x"]] + x + ((0.75) * width)
        microwaveSmallScreen[["y"]] <- microwaveSmallScreen[["y"]] + (y + (height / 1.7))

        # Touchpad

        numberOne <- shapeUtility[["Square"]](list("size" = width / 18))
        numberOne[["x"]] <- numberOne[["x"]] + x + ((0.75) * width)
        numberOne[["y"]] <- numberOne[["y"]] + (y + (height / 2.5))

        numberTwo <- shapeUtility[["Square"]](list("size" = width / 18))
        numberTwo[["x"]] <- numberTwo[["x"]] + x + ((0.83) * width)
        numberTwo[["y"]] <- numberTwo[["y"]] + (y + (height / 2.5))

        numberThree <- shapeUtility[["Square"]](list("size" = width / 18))
        numberThree[["x"]] <- numberThree[["x"]] + x + ((0.91) * width)
        numberThree[["y"]] <- numberThree[["y"]] + (y + (height / 2.5))

        numberFour <- shapeUtility[["Square"]](list("size" = width / 18))
        numberFour[["x"]] <- numberFour[["x"]] + x + ((0.75) * width)
        numberFour[["y"]] <- numberFour[["y"]] + (y + (height / 3.5))

        numberFive <- shapeUtility[["Square"]](list("size" = width / 18))
        numberFive[["x"]] <- numberFive[["x"]] + x + ((0.83) * width)
        numberFive[["y"]] <- numberFive[["y"]] + (y + (height / 3.5))

        numberSix <- shapeUtility[["Square"]](list("size" = width / 18))
        numberSix[["x"]] <- numberSix[["x"]] + x + ((0.91) * width)
        numberSix[["y"]] <- numberSix[["y"]] + (y + (height / 3.5))

        numberSeven <- shapeUtility[["Square"]](list("size" = width / 18))
        numberSeven[["x"]] <- numberSeven[["x"]] + x + ((0.75) * width)
        numberSeven[["y"]] <- numberSeven[["y"]] + (y + (height / 5.5))

        numberEight <- shapeUtility[["Square"]](list("size" = width / 18))
        numberEight[["x"]] <- numberEight[["x"]] + x + ((0.83) * width)
        numberEight[["y"]] <- numberEight[["y"]] + (y + (height / 5.5))

        numberNine <- shapeUtility[["Square"]](list("size" = width / 18))
        numberNine[["x"]] <- numberNine[["x"]] + x + ((0.91) * width)
        numberNine[["y"]] <- numberNine[["y"]] + (y + (height / 5.5))

        # # Microwave Handle
        microwaveHandle <- shapeUtility[["Rectangle"]](list("width" = width * 0.05, "height" = height * 0.7))
        microwaveHandle[["x"]] <- microwaveHandle[["x"]] + x + ((0.65) * width)
        microwaveHandle[["y"]] <- microwaveHandle[["y"]] + (y + (height / 7))

        return(list(
            list(coordinates = microwave, colour = colour),
            list(coordinates = microwaveMainScreen, colour = "#C0C0C0"),
            list(coordinates = microwaveSmallScreen, colour = "#C0C0C0"),
            list(coordinates = numberOne, colour = "#C0C0C0"),
            list(coordinates = numberTwo, colour = "#C0C0C0"),
            list(coordinates = numberThree, colour = "#C0C0C0"),
            list(coordinates = numberFour, colour = "#C0C0C0"),
            list(coordinates = numberFive, colour = "#C0C0C0"),
            list(coordinates = numberSix, colour = "#C0C0C0"),
            list(coordinates = numberSeven, colour = "#C0C0C0"),
            list(coordinates = numberEight, colour = "#C0C0C0"),
            list(coordinates = numberNine, colour = "#C0C0C0"),
            list(coordinates = microwaveHandle, colour = "#C0C0C0")
        ))
    }

    if (type == "Wall Mounted") {
        microwaveTouchpad <- shapeUtility[["Rectangle"]](list("width" = width * 0.9, "height" = height * 0.2))
        microwaveTouchpad[["x"]] <- microwaveTouchpad[["x"]] + x + (0.05) * width
        microwaveTouchpad[["y"]] <- microwaveTouchpad[["y"]] + (y + (height / 1.4))

        microwaveWallScreen <- shapeUtility[["Rectangle"]](list("width" = width * 0.9, "height" = height * 0.47))
        microwaveWallScreen[["x"]] <- microwaveWallScreen[["x"]] + x + (0.05) * width
        microwaveWallScreen[["y"]] <- microwaveWallScreen[["y"]] + (y + (height / 9))

        microwaveWallHandle <- shapeUtility[["Rectangle"]](list("width" = width * 0.9, "height" = height * 0.05))
        microwaveWallHandle[["x"]] <- microwaveWallHandle[["x"]] + x + (0.05) * width
        microwaveWallHandle[["y"]] <- microwaveWallHandle[["y"]] + (y + (height / 1.6))

        return(list(
            list(coordinates = microwave, colour = colour),
            list(coordinates = microwaveTouchpad, colour = "#C0C0C0"),
            list(coordinates = microwaveWallScreen, colour = "#C0C0C0"),
            list(coordinates = microwaveWallHandle, colour = "#C0C0C0")
        ))
    }
}
