#Loads data from Microwave.Designer class which contains functions for getting different finishes
source("R/Microwave.Designer.R")

Microwave.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added non-adjustable option for microwave height and width to follow industry standards.
            # User will have the option select a microwave with fixed dimensions from the dropdown list.
            selectInput(ns(".brand"), "Select Microwave Brand", getMicrowaveBrands(), selected = specs[["brand"]]),
            selectInput(ns(".finish"), "Select Microwave Brand", getMicrowaveFinishes(), selected = specs[["finish"]]), # nolint: line_length_linter.
            selectInput(ns(".type"), "Select Microwave Type", getMicrowaveTypes(), selected = specs[["type"]]), # nolint: line_length_linter.
            selectInput(ns(".dim"), "Microwave Dimensions in Millimetres (H x W)", c("470 x 585"), selected = dim), # nolint: line_length_linter.
            
            #Slider to move microwave left and right
            sliderInput(ns(".x"), "Move Microwave Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),

            #Slider to move microwave up and down
            sliderInput(ns(".y"), "Move Microwave Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
