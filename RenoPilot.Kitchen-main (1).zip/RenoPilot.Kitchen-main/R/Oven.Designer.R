ovenTypes <- c("Single Door with Cooktop", "Wall Mounted Double Door")

# Read all finishes from a CSV file to a dataframe.
ovenFinishesDF <- read.csv("data/oven_finishes.csv")

# Initialise lists to store the attributes of a oven
ovenFinishes <- list()

# Method to extract each column from the data frame of oven finishes
setUpOvenFinishes <- function() {
    finishes <- ovenFinishesDF[, c(1)]
    rgb <- ovenFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        ovenFinishes[[key]] <- value
    }

    return(ovenFinishes)
}

ovenFinishes <- setUpOvenFinishes()

# Return a list of strings oven finishes
getOvenFinishes <- function() {
    return(names(ovenFinishes))
}

# Return a list of strings oven types
getOvenTypes <- function() {
    return(ovenTypes)
}

Oven.Designer <- function(model) {
    
    # Construct basic shapes for oven
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract attributes for oven
    colour <- ovenFinishes[[specifications[["finish"]]]]
    type <- specifications[["type"]]

    # Draw basic oven body
    oven <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    oven[["x"]] <- oven[["x"]] + x
    oven[["y"]] <- oven[["y"]] + y

    # Render type of oven depending on UI input
    if (type == "Single Door with Cooktop") {
        ovenScreen <- shapeUtility[["Rectangle"]](list("width" = width * 0.6, "height" = height * 0.5))
        ovenScreen[["x"]] <- ovenScreen[["x"]] + x + ((0.2) * width)
        ovenScreen[["y"]] <- ovenScreen[["y"]] + (y + (height / 8))

        ovenKnobOne <- shapeUtility[["Circle"]](list("radius" = width / 16))
        ovenKnobOne[["x"]] <- ovenKnobOne[["x"]] + x + (0.25 * width)
        ovenKnobOne[["y"]] <- ovenKnobOne[["y"]] + (y + (height / 1.3))

        ovenKnobTwo <- shapeUtility[["Circle"]](list("radius" = width / 16))
        ovenKnobTwo[["x"]] <- ovenKnobTwo[["x"]] + x + ((0.5) * width)
        ovenKnobTwo[["y"]] <- ovenKnobTwo[["y"]] + (y + (height / 1.3))

        ovenKnobThree <- shapeUtility[["Circle"]](list("radius" = width / 16))
        ovenKnobThree[["x"]] <- ovenKnobThree[["x"]] + x + ((0.75) * width)
        ovenKnobThree[["y"]] <- ovenKnobThree[["y"]] + (y + (height / 1.3))

        # For the cooktop
        saucepanBody <- shapeUtility[["Rectangle"]](list("width" = width * 0.3, "height" = height * 0.2))
        saucepanBody[["x"]] <- saucepanBody[["x"]] + x + ((0.5) * width)
        saucepanBody[["y"]] <- saucepanBody[["y"]] + (y + (height))

        saucepanHandle <- shapeUtility[["Rectangle"]](list("width" = width * 0.2, "height" = height * 0.05))
        saucepanHandle[["x"]] <- saucepanHandle[["x"]] + x + ((0.8) * width)
        saucepanHandle[["y"]] <- saucepanHandle[["y"]] + (y + height + 70)

        return(list(
            list(coordinates = oven, colour = colour),
            list(coordinates = ovenScreen, colour = "#C0C0C0"),
            list(coordinates = ovenKnobOne, colour = "#C0C0C0"),
            list(coordinates = ovenKnobTwo, colour = "#C0C0C0"),
            list(coordinates = ovenKnobThree, colour = "#C0C0C0"),
            list(coordinates = saucepanBody, colour = "#000000"),
            list(coordinates = saucepanHandle, colour = "#925709")
        ))
    }

    if (type == "Wall Mounted Double Door") {
        ovenScreenOne <- shapeUtility[["Rectangle"]](list("width" = width * 0.65, "height" = height * 0.2))
        ovenScreenOne[["x"]] <- ovenScreenOne[["x"]] + x + ((0.2) * width)
        ovenScreenOne[["y"]] <- ovenScreenOne[["y"]] + (y + (height - 350))

        ovenScreenTwo <- shapeUtility[["Rectangle"]](list("width" = width * 0.65, "height" = height * 0.2))
        ovenScreenTwo[["x"]] <- ovenScreenTwo[["x"]] + x + ((0.2) * width)
        ovenScreenTwo[["y"]] <- ovenScreenTwo[["y"]] + (y + (height - 500))

        ovenKnobOne <- shapeUtility[["Square"]](list("size" = width / 8))
        ovenKnobOne[["x"]] <- ovenKnobOne[["x"]] + x + ((0.2) * width)
        ovenKnobOne[["y"]] <- ovenKnobOne[["y"]] + (y + (height / 1.4))

        ovenKnobTwo <- shapeUtility[["Square"]](list("size" = width / 8))
        ovenKnobTwo[["x"]] <- ovenKnobTwo[["x"]] + x + ((0.42) * width)
        ovenKnobTwo[["y"]] <- ovenKnobTwo[["y"]] + (y + (height / 1.4))

        ovenKnobThree <- shapeUtility[["Square"]](list("size" = width / 8))
        ovenKnobThree[["x"]] <- ovenKnobThree[["x"]] + x + ((0.65) * width)
        ovenKnobThree[["y"]] <- ovenKnobThree[["y"]] + (y + (height / 1.4))

        return(list(
            list(coordinates = oven, colour = colour),
            list(coordinates = ovenScreenOne, colour = "#C0C0C0"),
            list(coordinates = ovenScreenTwo, colour = "#C0C0C0"),
            list(coordinates = ovenKnobOne, colour = "#C0C0C0"),
            list(coordinates = ovenKnobTwo, colour = "#C0C0C0"),
            list(coordinates = ovenKnobThree, colour = "#C0C0C0")
        ))
    }
}
