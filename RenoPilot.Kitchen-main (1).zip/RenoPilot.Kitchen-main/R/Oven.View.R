#Import shiny library
library(shiny)

#Loads data from Oven.Designer class which contains functions for getting different finishes
source("R/Oven.Designer.R")
Oven.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            # Added non-adjustable option for oven height and width to follow industry standards.
            # User will have the option select a oven with fixed dimensions from the dropdown list.
            selectInput(ns(".finish"), "Select Oven Finish", getOvenFinishes(), selected = specs[["finish"]]), # nolint: line_length_linter.
            selectInput(ns(".type"), "Select Oven Type", getOvenTypes(), selected = specs[["type"]]), # nolint: line_length_linter.
            selectInput(ns(".dim"), "Oven Dimensions in Millimetres (H x W)", c("595 x 595", "595 x 895"), selected = dim), # nolint: line_length_linter.
            
            #Slider to move oven left and right
            sliderInput(ns(".x"), "Move Oven Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),

            #Slider to move oven up and down
            sliderInput(ns(".y"), "Move Oven Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
