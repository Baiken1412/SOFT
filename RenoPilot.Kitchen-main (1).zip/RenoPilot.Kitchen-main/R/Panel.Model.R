# Position
# x: int
# y: int

# Dimensions
# width: int
# height: int

# Specifications
# finish: string

# The Model in the MVC architecture that holds the attributes of a component
Panel.Model <- \(specifications) reactiveValues(
     id = uuid::UUIDgenerate(), # All models MUST have this
     type = "Panel", # ALL models MUST have this
     x = 0,
     y = 0,
     width = 200,
     height = 200,
     specifications = specifications
)
