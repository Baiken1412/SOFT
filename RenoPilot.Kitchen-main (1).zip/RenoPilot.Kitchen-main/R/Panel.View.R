#Import shiny library
library(shiny)

Panel.View <- \(model){
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    id <- model[["id"]]
    specs <- model[["specifications"]]
    ns <- NS(id)
    return(
        div(
            # Added non-adjustable option for panel height and width to follow industry standards.
            # User will have the option select a panel with fixed dimensions from the dropdown list.
            selectInput(ns(".finish"), "Finish on Panel", getPanelFinishes(), selected = specs[["finish"]]),
            selectInput(ns(".h"), "Height", c(200, 300, 400), selected = h),
            selectInput(ns(".w"), "Width", c(200, 300, 400, 500, 600), selected = w),
            #Slider to move panel left and right
            sliderInput(ns(".x"), "Horizontal Position", value = x, min = 0, max = kitchenDimensions[["width"]] - w),
            #Slider to move panel up and down
            sliderInput(ns(".y"), "Vertical Position", value = y, min = 0, max = kitchenDimensions[["height"]] - h)
        )
    )
}
