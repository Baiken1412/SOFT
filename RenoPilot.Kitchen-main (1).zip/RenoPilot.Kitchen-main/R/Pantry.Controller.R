#Import shiny library
library(shiny)

# All controllers should take an input, output and the model (as the ID is required to bind to the UI)

Pantry.Controller <- \(input, output, model){
    controller <- list()
    id <- model[["id"]]
    ns <- NS(id)

    retrievePantryDim <- function(dim) {
        dimStr <- dim
        dimList <- strsplit(dimStr[1], " x ")
        cabH <- as.integer(dimList[[1]][1])
        cabW <- as.integer(dimList[[1]][2])
        return(c(
            height = cabH,
            width = cabW
        ))
    }
#Update the x, y positions, height and width, finish and design according to user input 
    controller[["UPDATE"]] <- reactive({
        x <- as.numeric(input[[ns(".x")]])
        y <- as.numeric(input[[ns(".y")]])
        dimStr <- input[[ns(".dim")]]
        dimList <- retrievePantryDim(dimStr)
        height <- dimList[["height"]]
        width <- dimList[["width"]]
        finish <- input[[ns(".finish")]]

        model[["x"]] <- x
        model[["y"]] <- y
        model[["width"]] <- width
        model[["height"]] <- height
        model[["specifications"]] <- list(finish = finish)
    })

#Triggers UPDATE function if there are any changes to these events observed
    observeEvent(
        c(
            input[[ns(".x")]],
            input[[ns(".y")]],
            input[[ns(".w")]],
            input[[ns(".h")]],
            input[[ns(".dim")]],
            input[[ns(".finish")]]
        ),
        {
            controller[["UPDATE"]]()
        },
        ignoreInit = TRUE
    )

    return(controller)
}
