# Read all finishes from a CSV file to a dataframe.
pantryFinishesDF <- read.csv("data/door_finishes.csv")

# Initialise lists to store the attributes of a pantry
pantryFinishes <- list()

# Method to extract each column from the data frame of pantry finishes
setUpPantryFinishes <- function() {
    finishes <- pantryFinishesDF[, c(1)]
    rgb <- pantryFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        pantryFinishes[[key]] <- value
    }

    return(pantryFinishes)
}

pantryFinishes <- setUpPantryFinishes()

# Return a list of strings pantry finishes
getPantryFinishes <- function() {
    return(names(pantryFinishes))
}

Pantry.Designer <- function(model) {

    # Construct basic panel shapes
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specifications <- model[["specifications"]]

    # Extract panel attributes
    colour <- pantryFinishes[[specifications[["finish"]]]]


    #Draw basic panel shape based on the plot dimensions
    pantry <- shapeUtility[["Rectangle"]](list(width = width, height = height))
    pantry[["x"]] <- pantry[["x"]] + x
    pantry[["y"]] <- pantry[["y"]] + y

    ## Draw Pantry Knob
    pantryKnob <- shapeUtility[["Rectangle"]](list("width" = 50, "height" = 10))
    pantryKnob[["x"]] <- pantryKnob[["x"]] + x + 0.5 * width
    pantryKnob[["y"]] <- pantryKnob[["y"]] + (2 * y + height) / 2

    return(list(
        list(coordinates = pantry, colour = colour),
        list(coordinates = pantryKnob, colour = "#000000")
    ))
}
