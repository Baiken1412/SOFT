#Loads data from Pantry.Designer class which contains functions for getting different finishes
source("R/Pantry.Designer.R")

Pantry.View <- function(model) {
    id <- model[["id"]]
    specs <- model[["specifications"]]
    h <- model[["height"]]
    w <- model[["width"]]
    x <- model[["x"]]
    y <- model[["y"]]
    dim <- paste(h, "x", w)
    ns <- NS(id)
    return(
        tagList(
            selectInput("pantry.type", "Pantry Type", c("Shaker", "Sliding", "Wall Mounted")), # nolint: line_length_linter.
            selectInput(ns(".finish"), "Finish on Pantry", getPantryFinishes(), selected = specs[["finish"]]),

            # Added non-adjustable option for pantry height and width to follow industry standards.
            # User will have the option select a pantry with fixed dimensions from the dropdown list.
            selectInput(ns(".dim"), "Pantry Dimensions in Millimetres (H x W)", c("720 x 150", "720 x 300", "720 x 600", "720 x 900"), selected = dim), # nolint: line_length_linter.
            
            #Slider to move pantry left and right
            sliderInput(ns(".x"), "Move Pantry Left or Right",
                min = 0, max = kitchenDimensions[["width"]] - w, value = x
            ),

            #Slider to move pantry up and down
            sliderInput(ns(".y"), "Move Pantry Up or Down",
                min = 0, max = kitchenDimensions[["height"]] - h, value = y
            )
        )
    )
}
