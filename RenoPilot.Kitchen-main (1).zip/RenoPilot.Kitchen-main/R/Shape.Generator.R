# coordinates listed in a counterclockwise manner ending at the starting point
Shape.Generator <- \() {
  utility <- Geometry.Utility()

  generators <- list()
  generators[['Square']]    <- \(specifications) {
    data.frame(
      x = c(
        0,
        specifications[['size']],
        specifications[['size']],
        0,
        0
      ),
      y = c(
        0,
        0,
        specifications[['size']],
        specifications[['size']],
        0
      )
    )
  }
  generators[['Rectangle']] <- \(specifications) {
    data.frame(
      x = c(
        0,
        specifications[['width']],
        specifications[['width']],
        0,
        0
      ),
      y = c(
        0,
        0,
        specifications[['height']],
        specifications[['height']],
        0
      )
    )
  }
  generators[['Triangle']]  <- \(specifications) {
    data.frame(
      x = c(
        0,
        specifications[['width']],
        specifications[['width']] / 2,
        0
      ),
      y = c(
        0,
        0,
        specifications[['height']],
        0
      )
    )
  }
  generators[['Trapezoid']] <- \(specifications) {
    width  <- specifications[['bottom']] |> max(specifications[['top']])
    height <- specifications[['height']]

    coordinates <- list(width = width, height = height) |> generators[['Rectangle']]()

    difference  <- (specifications[['bottom']] - specifications[['top']]) |> abs()
    
    if (specifications[['bottom']] < specifications[['top']]) {
      coordinates[['x']][1] <- (difference / 2)
      coordinates[['x']][2] <- coordinates[['x']][2] - (difference / 2)
      coordinates[['x']][5] <- (difference / 2)
    }
    
    if (specifications[['bottom']] > specifications[['top']]) {
      coordinates[['x']][3] <- coordinates[['x']][3] - (difference / 2)
      coordinates[['x']][4] <- coordinates[['x']][4] + (difference / 2) 
    }

    return(coordinates)
  }
  generators[['Circle']]    <- \(specifications) {
    angle.converter    <- Angle.Converter()
    geometry.converter <- Geometry.Converter()

    angle <- seq(0, 360, 10) |> angle.converter[['degreesToRadians']]()
    radius <- specifications[['radius']] |> rep(length(angle))

    coordinates <- data.frame(angle, radius) |> 
      geometry.converter[['polarToCartesian']]()

    return(coordinates)
  }
  generators[['Segment']]   <- \(specifications) {
    angle.converter    <- Angle.Converter()
    geometry.converter <- Geometry.Converter()

    start <- specifications[['start']]
    end   <- specifications[['end']]

    angle <- start |> seq(end, 10) |> angle.converter[['degreesToRadians']]()
    radius <- specifications[['radius']] |> rep(length(angle))

    offset <- data.frame(
      x = specifications[['radius']],
      y = 0
    )
    coordinates <- data.frame(angle, radius) |> 
      geometry.converter[['polarToCartesian']]() |>
      utility[['translate']](offset)

  }
  return(generators)
}
