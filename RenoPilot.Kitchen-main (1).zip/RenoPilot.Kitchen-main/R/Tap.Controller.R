#Import shiny library
library(shiny)

# All controllers should take an input, output and the model (as the ID is required to bind to the UI)
Tap.Controller <- \(input, output, model){
    controller <- list()
    id <- model[["id"]]
    ns <- NS(id)

#Update the x, y positions, height and width, finish and design according to user input

    controller[["UPDATE"]] <- reactive({
        x <- as.numeric(input[[ns(".x")]])
        y <- as.numeric(input[[ns(".y")]])
        finish <- input[[ns(".finish")]]

        model[["x"]] <- x
        model[["y"]] <- y
        model[["specifications"]] <- list(finish = finish)
    })
    
#Triggers UPDATE function if there are any changes to these events observed
    observeEvent(
        c(
            input[[ns(".x")]],
            input[[ns(".y")]],
            input[[ns(".finish")]]
        ),
        {
            controller[["UPDATE"]]()
        },
        ignoreInit = TRUE
    )

    return(controller)
}
