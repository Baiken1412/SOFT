# Read all finishes from a CSV file to a dataframe.
tapFinishesDF <- read.csv("data/tap_finishes.csv")

# Initialise lists to store the attributes of a tap
tapFinishes <- list()

# Method to extract each column from the data frame of tap finishes
setUpTapFinishes <- function() {
    finishes <- tapFinishesDF[, c(1)]
    rgb <- tapFinishesDF[, c(2)]

    ## Iterate through the dataframe to get the key value pair in the CSV (Key --> Finish, Value --> RGB)
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        tapFinishes[[key]] <- value
    }

    return(tapFinishes)
}

tapFinishes <- setUpTapFinishes()

# Return a list of strings tap finishes
getTapFinishes <- function() {
    return(names(tapFinishes))
}

Tap.Designer <- \(model){

    # Construct basic panel shapes
    shapeUtility <- Shape.Generator()
    specs <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]

    #Extract tap attributes
    colour <- tapFinishes[[specs[["finish"]]]]

    # Draw tap as per the size of the plot dimensions
    tapBody <- shapeUtility[["Rectangle"]](list("width" = width, "height" = height))
    tapBody[["x"]] <- tapBody[["x"]] + x
    tapBody[["y"]] <- tapBody[["y"]] + y

    tapBodyOne <- shapeUtility[["Rectangle"]](list("width" = height, "height" = width))
    tapBodyOne[["x"]] <- tapBodyOne[["x"]] + x
    tapBodyOne[["y"]] <- tapBodyOne[["y"]] + y + 150

    tapBodyTwo <- shapeUtility[["Square"]](list("size" = 50))
    tapBodyTwo[["x"]] <- tapBodyTwo[["x"]] + x + 100
    tapBodyTwo[["y"]] <- tapBodyTwo[["y"]] + y + 100

    return(
        list(
            list(coordinates = tapBody, colour = colour),
            list(coordinates = tapBodyOne, colour = colour),
            list(coordinates = tapBodyTwo, colour = colour)
        )
    )
}
