#Loads data from Tap.Designer class which contains functions for getting different finishes
source("R/Tap.Designer.R")

Tap.View <- \(model){
    spec <- model[["specifications"]]
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    id <- model[["id"]]
    ns <- NS(id)
    return(
        tagList(
            #Gets finishes for tap, with no size option
            selectInput(ns(".finish"), "Finish on Tap", getTapFinishes(), selected = spec[["finish"]]),
            
            #Slider to move tap left and right
            sliderInput(ns(".x"), "Move Tap Left or Right", value = x, min = 0, max = kitchenDimensions[["width"]] - w),
            
            #Slider to move tap up and down
            sliderInput(ns(".y"), "Move Tap Up or Down", value = y, min = 0, max = kitchenDimensions[["height"]] - h),
        )
    )
}
