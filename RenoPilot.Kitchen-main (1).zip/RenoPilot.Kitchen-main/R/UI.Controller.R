library(shiny)

# The main controller component which holds all the other controllers within the
# MVC architecture
UI.Controller <- \(input, output){
    state <- reactiveValues()
    viewFactory <- Factory.View()
    designerFactory <- Factory.Designer()
    modelFactory <- Factory.Model()
    controllerFactory <- Factory.Controller()

    state[["components"]] <- list()
    state[["component"]] <- NULL
    controller <- list()

    # Gets all the rows of the components by ID
    controller[["GETROWS"]] <- \(){
        ids <- lapply(state[["components"]], \(element) {
            element[["id"]]
        })

    # Gets all the rows of the components by type
        types <- lapply(state[["components"]], \(element){
            element[["type"]]
        })

        values <- data.frame(
            id = unlist(ids),
            Component = unlist(types)
        )
        return(values)
    }

    # Adds a component to the plot
    controller[["ADD"]] <- \(model){
        state[["components"]] <- append(state[["components"]], list(model))
    }

    # Removes a component to the plot
    controller[["DELETE"]] <- \(){
        if (length(input[["components.list_rows_selected"]])) {
            row <- input[["components.list_rows_selected"]]
            state[["components"]] <- state[["components"]][-row]
        }
    }

    # Waits for an event to occur for the state of a component for selecting multiple rows that
    # list all the components
    observeEvent(input[["components.list_rows_selected"]], ignoreNULL = FALSE, {
        if (length(input[["components.list_rows_selected"]])) {
            rows <- input[["components.list_rows_selected"]]
            state[["component"]] <- state[["components"]][rows]
        } else {
            state[["component"]] <- NULL
        }
    })




    observeEvent(input[["component.add"]], {
        type <- input[["component.dropdown"]]
        model <- modelFactory(type)
        controller[["ADD"]](model)
    })

    observeEvent(input[["component.delete"]], {
        controller[["DELETE"]]()
    })

    observeEvent(input[["kitchen.save"]], {
        kitchenDimensions[["width"]] <- as.numeric(input[["kitchen.width"]])
        kitchenDimensions[["height"]] <- as.numeric(input[["kitchen.height"]])
    })

    output[["export.file"]] <- downloadHandler(
        filename = "kitchen_design.json",
        contentType = "application/json",
        content = function(file) {
            components <- lapply(state[["components"]], \(value) reactiveValuesToList(value))
            data <- list(
                kitchenWidth = kitchenDimensions[["width"]],
                kitchenHeight = kitchenDimensions[["height"]],
                components = components
            )
            writeLines(toJSON(data), file)
        }
    )

    observeEvent(input[["import.file"]], {
        file <- input[["import.file"]]

        ext <- tools::file_ext(file$datapath)

        req(file)
        validate(need(ext == "json", "Please upload a JSON file"))


        file <- input[["import.file"]][[4]]

        data <- fromJSON(file = file)
        kitchenDimensions[["width"]] <- data[["kitchenWidth"]]
        kitchenDimensions[["height"]] <- data[["kitchenHeight"]]
        components <- data[["components"]]
        state[["components"]] <- list()
        state[["component"]] <- NULL
        for (component in components) {
            builder <- Builder.Model()
            builder[["setType"]](component[["type"]])
            builder[["setX"]](component[["x"]])
            builder[["setY"]](component[["y"]])
            builder[["setWidth"]](component[["width"]])
            builder[["setHeight"]](component[["height"]])
            builder[["setSpecs"]](component[["specifications"]])
            model <- builder[["build"]]()
            controller[["ADD"]](model)
        }
    })

    output[["import.file.err"]] <- renderText({
        file <- input[["import.file"]]

        ext <- tools::file_ext(file$datapath)

        req(file)
        validate(need(ext == "json", "Please upload a JSON file"))
    })




    output[["selected.component"]] <- renderUI({
        models <- state[["component"]]

        if (length(models) == 1) {
            model <- models[[1]]
            modelController <- controllerFactory(model[["type"]])
            modelView <- viewFactory(model[["type"]])
            modelController(input, output, model)
            return(modelView(model))
        } else if (length(models) > 1) {
            id <- uuid::UUIDgenerate()
            observers <- Format.Controller(id, input, output, models)
            return(Format.View(id))
        }
    })

    table.options <- list(
        dom = "tp",
        ordering = FALSE,
        autoWidth = TRUE,
        columnDefs = list(
            list(visible = FALSE, targets = c(1)),
            list(width = "500px", targets = c(1)),
            list(className = "dt-center", targets = c(1))
        )
    )


    output[["components.list"]] <- DT::renderDataTable({
        DT::datatable(
            controller[["GETROWS"]](),
            selection = "multiple",
            rownames = TRUE,
            options = table.options
        )
    })


    output[["plot"]] <- renderPlot({
        plot(1,
            type = "n",
            xlab = "Width",
            ylab = "Height",
            xlim = c(0, kitchenDimensions[["width"]]),
            ylim = c(0, kitchenDimensions[["height"]]),
        )

        selectedComponents <- unlist(lapply(state[["component"]], \(model){
            model[["id"]]
        }))

        for (model in state[["components"]]) {
            designer <- designerFactory(model[["type"]])
            shapes <- designer(model)
            for (shape in shapes) {
                x <- shape[["coordinates"]][["x"]]
                y <- shape[["coordinates"]][["y"]]
                colour <- shape[["colour"]]
                lwd <- 1
                border <- "black"
                if (model[["id"]] %in% selectedComponents) {
                    lwd <- 3
                    border <- "blue"
                }

                polygon(
                    x = unlist(x),
                    y = unlist(y),
                    col = colour,
                    lwd = lwd,
                    border = border
                )
            }
        }
    })
    # logic to for download button - save to pdf
    output[["export.pdf"]] <- downloadHandler(
        filename = "kitchen_design.pdf",
        contentType = "application/pdf",
        content = function(file) {
            pdf(file)
            # print(plotOutput("plot"))
            plot(1,
                type = "n",
                xlab = "Width",
                ylab = "Height",
                xlim = c(0, kitchenDimensions[["width"]]),
                ylim = c(0, kitchenDimensions[["height"]]),
                asp = 1
            )

            for (model in state[["components"]]) {
                designer <- designerFactory(model[["type"]])
                shapes <- designer(model)
                for (shape in shapes) {
                    x <- shape[["coordinates"]][["x"]]
                    y <- shape[["coordinates"]][["y"]]
                    colour <- shape[["colour"]]
                    lwd <- 1
                    border <- "black"

                    polygon(
                        x = unlist(x),
                        y = unlist(y),
                        col = colour,
                        lwd = lwd,
                        border = border
                    )
                }
            }
            dev.off()
        }
    )
}
