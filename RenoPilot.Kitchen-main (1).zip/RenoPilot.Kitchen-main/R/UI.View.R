library(shiny)
# Store all the components names as a list.
component.names <- list(
    "Storage units" = c("Cabinet", "Cupboard", "Pantry"),
    "Appliances" = c("Canopy", "Dishwasher", "Fridge", "Microwave", "Oven"),
    "Miscellaneous" = c("Panel", "Door", "Tap", "Benchtop")
)

# Contains the main view of the kitchen generator such as the general properties
# of a plot such as the plot dimensions, options to save plot as a JSON and PDF 
# as well as the sliders to move the components up and down
UI.View <- \(id){
    ns <- NS(id)
    fluidRow(
        column(
            4,
            h1("Kitchen Dimensions"),
            h5("Set your Kitchen width and height"),
            div(
                numericInput("kitchen.width", value = defaultWidth, label = "Width (mm)", min = 0, step = 1),
                numericInput("kitchen.height", value = defaultHeight, label = "Height (mm)", min = 0, step = 1),
                actionButton("kitchen.save", "Save Dimension", width = "100%"),
                downloadButton("export.pdf", "Export to PDF", class = "downBtn"),
                downloadButton("export.file", "Export to JSON", class = "downBtn"),
                textOutput("import.file.err"),
                fileInput("import.file", label = "Import from JSON", accept = ".json", width = "100%"),
            )
        ),
        column(
            4,
            h1("Kitchen Components"),
            h5("Select a component from the table below to customise."),
            DT::dataTableOutput(
                "components.list"
            ),
            selectInput("component.dropdown", label = "Components", choices = component.names),
            actionButton("component.add", "Add"),
            actionButton("component.delete", "Delete")
        ),
        column(
            4,
            uiOutput("selected.component")
        )
    )
}
