# RenoPilot.Kitchen

### What is this app?

This application is the RenoPilot Kitchen Generator application, built using R and Shiny. The app allows users to design a kitchen with a number of different types of kitchen components and make use of design tools to assemble their dream kitchen design. Once they're done, users can save their design as a PDF to their computer.

## How to Containerise and Run the application

A Dockerfile is included in this repository that will create a Docker container with the Shiny application and all of its dependent R packages. To build the image, run:
`docker build -t renopilot-kitchen .`

This will take a few minutes to run as all dependencies are created and necessary packages for Ubuntu are assembled. Once this is completed, an image called `renopilot-kitchen` will be created. To run it, use the following command:
`docker run -p 8080:3838 renopilot-kitchen`

Then, you can access the application at `https://localhost:3838`.

### How do I run this app locally?

You can run this app locally without the container using `shiny::runApp()` in an R console. Make sure before you run this, you have the Shiny module loaded. If you do not, you can obtain it by running `install.packages("shiny")` in your R console first.

### How do I run the tests for this app?

You can run the test suite by running `devtools::test()` in an R console. If you don't have devtools installed, run `install.packages("devtools")` first to get this working.

### Who made this?

SOFT3888 Group 21 from the University of Sydney during Semester 2, 2023 under the guidance of RenoPilot Pty Ltd. See `DESCRIPTION` for more detail about the makers of this application.
