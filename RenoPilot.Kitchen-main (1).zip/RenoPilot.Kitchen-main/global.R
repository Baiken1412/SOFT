library(dplyr)
library(shiny)
library(shinydashboard)
library(DT)
library(uuid)
library(rjson)

# Add customised style sheets
Custom.Style <- \() tags$head(
  tags$link(
    rel = "stylesheet",
    type = "text/css",
    href = "style.css"
  )
)

# Default plot height and width
defaultWidth <- 5000
defaultHeight <- 3000

# Changing plot dimensions according to user input
kitchenDimensions <- reactiveValues(width = defaultWidth, height = defaultHeight)


getKitchenWidth <- reactive({
  return(kitchenDimensions[["width"]])
})

getKitchenHeight <- reactive({
  return(kitchenDimensions[["height"]])
})
