library(shiny)
source("R/UI.Controller.R")

# Server takes input and output to the main UI.Controller
server <- \(input, output) {
  UI.Controller(input, output)
}
