test_that("setUpBenchtopFinishes sets up benchtop finishes correctly", {
    
    # Set up benchtop finishes
    benchtopFinishes <- setUpBenchtopFinishes()
    
    # Test that benchtop finishes are set up correctly
    expect_true(is.list(benchtopFinishes))
    expect_equal(length(benchtopFinishes), 26)
    expect_equal(benchtopFinishes[["Alpine White Quadra"]], "#F3F3F3")
    expect_equal(benchtopFinishes[["Tobacco Halifax Oak Streamline"]], "#91735A")
})

test_that("setUpBenchtopTypes sets up benchtop types correctly", {
    
    # Set up benchtop types
    benchtopTypes <- setUpBenchtopTypes()
    
    # Test that benchtop types are set up correctly
    expect_equal(length(benchtopTypes), 52)
    expect_false("Finish1" %in% benchtopTypes)
    expect_true("Caesarstone" %in% benchtopTypes)
})

test_that("Benchtop.Designer returns the expected shape for a given model", {
    # Example model data (you can adjust this)
    model <- list(
        x = 100,
        y = 200,
        width = 300,
        height = 400,
        specifications = list(
            finish = "Noble Grey",
            type = "Type1"
        )
    )
    
    # Call Benchtop.Designer
    shapes <- Benchtop.Designer(model)
    
    # Test the properties of the shape as needed
    expect_true(is.list(shapes))
    expect_equal(length(shapes), 1)  # Assuming there is 1 shape in the output
    
    # For example, test the properties of the shape
    shape <- shapes[[1]]
    expect_true(is.list(shape))
    expect_true(all(c("coordinates", "colour") %in% names(shape)))
    expect_type(shape$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape$coordinates)))
    expect_type(shape$colour, "character")
})
