
test_that("setUpCabinetFinishes correctly sets up cabinet finishes", {
  # Call the setUpCabinetFinishes function
  cabinetFinishes <- setUpCabinetFinishes()
  
  # Check if cabinet finishes are set up correctly
  expect_equal(length(cabinetFinishes), 14)  # Expected number of finishes
  
  # Check if specific finishes are present
  expect_true("Classic White Matt" %in% names(cabinetFinishes))
  expect_true("Alabaster Matt" %in% names(cabinetFinishes))
  expect_true("Amaro Matt" %in% names(cabinetFinishes))
  
  # Check if RGB values are correctly associated with finishes
  expect_equal(cabinetFinishes[["Classic White Matt"]], "#fcfbf7")
  expect_equal(cabinetFinishes[["Alabaster Matt"]], "#fcf7e3")
  expect_equal(cabinetFinishes[["Amaro Matt"]], "#dbd8ca")
})

test_that("getCabinetFinishes correctly retrieves cabinet finishes", {
  # Call the getCabinetFinishes function
  cabinetFinishes <- getCabinetFinishes()
  
  # Check if cabinet finishes are retrieved correctly
  expect_equal(length(cabinetFinishes), 14)  # Expected number of finishes
  
  # Check if specific finishes are present
  expect_true("Classic White Matt" %in% cabinetFinishes)
  expect_true("Alabaster Matt" %in% cabinetFinishes)
  expect_true("Amaro Matt" %in% cabinetFinishes)
})
