# Function to set up canopy finishes
setUpCanopyFinishes <- function() {
    finishes <- canopyFinishesDF[, c(1)]
    rgb <- canopyFinishesDF[, c(2)]
    
    canopyFinishes <- list()
    
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        canopyFinishes[[key]] <- value
    }
    
    return(canopyFinishes)
}

# Unit tests for setUpCanopyFinishes
test_that("setUpCanopyFinishes correctly sets up canopyFinishes", {
    canopyFinishes <- setUpCanopyFinishes()
    
    # Check that canopyFinishes is a list
    expect_true(is.list(canopyFinishes))
    
    # Check that it contains some expected finish keys
    expect_false("Finish1" %in% names(canopyFinishes))
    expect_true("Matte Black" %in% names(canopyFinishes))
    expect_true("Crimson" %in% names(canopyFinishes))
    
    # Check that the values are character strings
    expect_true(all(sapply(canopyFinishes, is.character)))
})

# Function to test Canopy.Designer
testCanopyDesigner <- function(model) {
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    width <- model[["width"]]
    height <- model[["height"]]
    specs <- model[["specifications"]]
    
    colour <- canopyFinishes[[specs[["finish"]]]]

    topRect <-  shapeUtility[["Rectangle"]](list(width = width * 0.5, height = height * 0.25))
    topRect[["x"]] <- topRect[["x"]] + x + 0.25 * width
    topRect[["y"]] <- topRect[["y"]] + y + 0.75 * height

    middleTrapezium <- shapeUtility[["Trapezoid"]](list(bottom = width, top = width * 0.5, height = height * 0.5))
    middleTrapezium[["x"]] <- middleTrapezium[["x"]] + x
    middleTrapezium[["y"]] <- middleTrapezium[["y"]] + y + 0.25 * height

    bottomUpperRect <- shapeUtility[["Rectangle"]](list(width = width, height = height * 0.2))
    bottomUpperRect[["x"]] <- bottomUpperRect[["x"]] + x
    bottomUpperRect[["y"]] <- bottomUpperRect[["y"]] + y + 0.05 * height

    bottomLowerRect <- shapeUtility[["Rectangle"]](list(width = width, height = height * 0.05))
    bottomLowerRect[["x"]] <- bottomLowerRect[["x"]] + x
    bottomLowerRect[["y"]] <- bottomLowerRect[["y"]] + y
    
    return(
        list(
            list(coordinates = topRect, colour = colour),
            list(coordinates = middleTrapezium, colour = colour),
            list(coordinates = bottomLowerRect, colour = colour),
            list(coordinates = bottomUpperRect, colour = colour)
        )
    )
}

# Unit tests for Canopy.Designer
test_that("Canopy.Designer returns the expected shapes for a given model", {
    # Example model data 
    model <- list(
        x = 100,
        y = 200,
        width = 300,
        height = 400,
        specifications = list(
            finish = "Crimson"
        )
    )
    
    # Call Canopy.Designer
    shapes <- Canopy.Designer(model)
    
    expect_true(is.list(shapes))
    expect_equal(length(shapes), 4)  # Assuming there are 4 shapes in the output
    
    # Tests for (topRect)
    shape1 <- shapes[[1]]
    expect_true(is.list(shape1))
    expect_true(all(c("coordinates", "colour") %in% names(shape1)))
    expect_type(shape1$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape1$coordinates)))
    expect_type(shape1$colour, "character")

    # Tests for (middleTrapezium)
    shape2 <- shapes[[2]]
    expect_true(is.list(shape2))
    expect_true(all(c("coordinates", "colour") %in% names(shape2)))
    expect_type(shape2$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape2$coordinates)))
    expect_type(shape2$colour, "character")
    
    # Tests for (bottomUpperRect)
    shape3 <- shapes[[3]]
    expect_true(is.list(shape3))
    expect_true(all(c("coordinates", "colour") %in% names(shape3)))
    expect_type(shape3$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape3$coordinates)))
    expect_type(shape3$colour, "character")
    
    # Tests for (bottomLowerRect)
    shape4 <- shapes[[4]]
    expect_true(is.list(shape4))
    expect_true(all(c("coordinates", "colour") %in% names(shape4)))
    expect_type(shape4$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape4$coordinates)))
    expect_type(shape4$colour, "character")
})

