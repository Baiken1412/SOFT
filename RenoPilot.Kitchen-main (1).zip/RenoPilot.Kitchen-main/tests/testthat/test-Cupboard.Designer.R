# Function to set up cupboard finishes
setUpCupboardFinishes <- function() {
    finishes <- cupboardFinishesDF[, c(1)]
    rgb <- cupboardFinishesDF[, c(2)]
    
    cupboardFinishes <- list()
    
    for (i in 1:length(finishes)) {
        key <- finishes[i]
        value <- rgb[i]
        cupboardFinishes[[key]] <- value
    }
    
    return(cupboardFinishes)
}

# Unit tests for setUpCupboardFinishes
test_that("setUpCupboardFinishes correctly sets up cupboardFinishes", {
    cupboardFinishes <- setUpCupboardFinishes()
    
    # Check that cupboardFinishes is a list
    expect_true(is.list(cupboardFinishes))
    
    # Check that it contains some expected finish keys 
    expect_true("Classic White Matt" %in% names(cupboardFinishes))
    expect_true("Coastal Oak" %in% names(cupboardFinishes))
    expect_true("Oxford Matt" %in% names(cupboardFinishes))
    
    # Check that the values are character strings
    expect_true(all(sapply(cupboardFinishes, is.character)))
})

# Function to test Cupboard.Designer
testCupboardDesigner <- function(model) {
    shapeUtility <- Shape.Generator()
    x <- model[["x"]]
    y <- model[["y"]]
    w <- model[["width"]]
    h <- model[["height"]]
    specifications <- model[["specifications"]]
    
    colour <- cupboardFinishes[[specifications[["finish"]]]]
    design <- specifications[["design"]]
    
    cupboardTop <- shapeUtility[["Rectangle"]](list(width = w, height = h / 2))
    cupboardTop[["x"]] <- cupboardTop[["x"]] + x
    cupboardTop[["y"]] <- cupboardTop[["y"]] + y + (h / 2)
    
    cupboardBot <- shapeUtility[["Rectangle"]](list(width = w, height = h / 2))
    cupboardBot[["x"]] <- cupboardBot[["x"]] + x
    cupboardBot[["y"]] <- cupboardBot[["y"]] + y
    
    rectKnobU <- shapeUtility[["Rectangle"]](list(width = w / 4, height = 5))
    rectKnobU[["x"]] <- rectKnobU[["x"]] + x + w / 2 - w / 8
    rectKnobU[["y"]] <- rectKnobU[["y"]] + y + 0.9 * h
    
    rectKnobB <- shapeUtility[["Rectangle"]](list(width = w / 4, height = 5))
    rectKnobB[["x"]] <- rectKnobB[["x"]] + x + w / 2 - w / 8
    rectKnobB[["y"]] <- rectKnobB[["y"]] + y + (h / 2) - 0.1 * h
    
    if (design == "Cora") {
        rect_L <- shapeUtility[["Rectangle"]](list("width" = w/1.09, "height" = h/2.5))
        rect_L[["x"]] <- rect_L[["x"]]+ x + (0.04 * w)
        rect_L[["y"]] <- rect_L[["y"]] + y + (0.55 * h)
        
        rect_R <- shapeUtility[["Rectangle"]](list("width" = w/1.09, "height" = h/2.5))
        rect_R[["x"]] <- rect_R[["x"]]+ x + (0.04 * w)
        rect_R[["y"]] <- rect_R[["y"]] + y + (0.05 * h)
        
        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rect_L, colour = colour),
                list(coordinates = rect_R, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }
    
    if (design == "Tiffany") {
        return(
            list(
                list(coordinates = cupboardTop, colour = colour),
                list(coordinates = cupboardBot, colour = colour),
                list(coordinates = rectKnobU, colour = colour),
                list(coordinates = rectKnobB, colour = colour)
            )
        )
    }
}

# Unit tests for Cupboard.Designer
test_that("Cupboard.Designer returns the expected shapes for a given model", {
    # Example model data 
    model <- list(
        x = 100,
        y = 200,
        width = 300,
        height = 400,
        specifications = list(
            finish = "Coastal Oak",
            design = "Cora"
        )
    )
    
    # Call Cupboard.Designer
    shapes <- Cupboard.Designer(model)
    
    # Test the properties of shapes as needed
    expect_true(is.list(shapes))
    expect_equal(length(shapes), 6)  # Assuming there are 6 shapes in the output
    
    shape1 <- shapes[[1]]
    expect_true(is.list(shape1))
    expect_true(all(c("coordinates", "colour") %in% names(shape1)))
    expect_type(shape1$coordinates, "list")
    expect_true(all(c("x", "y") %in% colnames(shape1$coordinates)))
    expect_type(shape1$colour, "character")

})

