test_that("setUpDishwasherFinishes returns a list of dishwasher finishes", {

  dishwasherFinishes <- setUpDishwasherFinishes()
  
  expect_type(dishwasherFinishes, "list")
  expect_equal(length(dishwasherFinishes), 8)
  expect_equal(names(dishwasherFinishes), c("Stainless Steel", "Wooden Finish", "Glossy Crimson", "Matte Black", "Black Stainless Steel", "Slate", "White", "Matte White"))
  expect_equal(dishwasherFinishes[["Finish1"]], NULL)
})

# Test for getDishwasherFinishes
test_that("getDishwasherFinishes returns the names of dishwasher finishes", {


  dishwasherFinishes <- setUpDishwasherFinishes()
  finishes <- getDishwasherFinishes()
  
  expect_type(finishes, "character")
  expect_equal(length(finishes), 8)
  expect_equal(finishes, c("Stainless Steel", "Wooden Finish", "Glossy Crimson", "Matte Black", "Black Stainless Steel", "Slate", "White", "Matte White"))
})

# Test for Dishwasher.Designer
test_that("Dishwasher.Designer returns a list of shapes for dishwasher components", {
  model <- list(
    x = 100,
    y = 200,
    width = 300,
    height = 400,
    specifications = list(
      finish = "Glossy Crimson",
      type = "Type1"
    )
  )
  shapes <- Dishwasher.Designer(model)
  
  expect_type(shapes, "list")
  expect_equal(length(shapes), 3)  # Assuming you have 3 dishwasher components
  expect_type(shapes[[1]], "list")  # Assuming each shape is a list
  expect_type(shapes[[2]], "list")
  expect_type(shapes[[3]], "list")
  
  # Test the coordinates and color properties of each shape
  expect_type(shapes[[1]]$coordinates, "list")
  expect_equal(ncol(shapes[[1]]$coordinates), 2)
  expect_equal(names(shapes[[1]]$coordinates), c("x", "y"))
  expect_type(shapes[[1]]$colour, "character")
  expect_equal(shapes[[1]]$colour, "#DA2108")  # Assuming Finish1 corresponds to this color
  

  dishwasherFinishes <- setUpDishwasherFinishes()
  
  expect_type(dishwasherFinishes, "list")
  expect_equal(length(dishwasherFinishes), 8)
  expect_equal(names(dishwasherFinishes), c("Stainless Steel", "Wooden Finish", "Glossy Crimson", "Matte Black", "Black Stainless Steel", "Slate", "White", "Matte White"))
})

# Test for getDishwasherFinishes
test_that("getDishwasherFinishes returns the names of dishwasher finishes", {

  dishwasherFinishes <- setUpDishwasherFinishes()
  finishes <- getDishwasherFinishes()
  
  expect_type(finishes, "character")
  expect_equal(length(finishes), 8)
  expect_equal(finishes, c("Stainless Steel", "Wooden Finish", "Glossy Crimson", "Matte Black", "Black Stainless Steel", "Slate", "White", "Matte White"))
})

# Test for Dishwasher.Designer
test_that("Dishwasher.Designer returns a list of shapes for dishwasher components", {
  model <- list(
    x = 100,
    y = 200,
    width = 300,
    height = 400,
    specifications = list(
      finish = "Wooden Finish",
      type = "Type1"
    )
  )
  shapes <- Dishwasher.Designer(model)
  
  expect_type(shapes, "list")
  expect_equal(length(shapes), 3)  # Assuming you have 3 dishwasher components
  expect_type(shapes[[1]], "list")  # Assuming each shape is a list
  expect_type(shapes[[2]], "list")
  expect_type(shapes[[3]], "list")
  
  # Test the coordinates and color properties of each shape
  expect_type(shapes[[1]]$coordinates, "list")
  expect_equal(ncol(shapes[[1]]$coordinates), 2)
  expect_equal(names(shapes[[1]]$coordinates), c("x", "y"))
  expect_type(shapes[[1]]$colour, "character")
  expect_equal(shapes[[1]]$colour, "#C4A67D")  # Assuming Finish1 corresponds to this color

})
