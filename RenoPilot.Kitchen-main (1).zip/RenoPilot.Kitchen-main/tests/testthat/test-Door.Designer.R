# Define a test case for the 'Door.Designer' function
test_that("Door.Designer returns a list of lists with valid coordinates and colors", {
  # Set up door finishes and designs
  doorFinishes <- setUpDoorFinishes()
  doorDesigns <- getDoorDesigns()
  
  # Create a sample model input
  model <- list(
    x = 0,  # Adjust these values as needed
    y = 0,  # Adjust these values as needed
    width = 100,  # Adjust these values as needed
    height = 200,  # Adjust these values as needed
    specifications = list(
      finish = doorFinishes[[1]],  # Use an actual finish name
      design = doorDesigns[[1]]  # Use an actual design name
    )
  )
  
  # Call the Door.Designer function
  result <- Door.Designer(model)
  
  # Check that the result is a list
  expect_type(result, "list")
  
  # Check that the result contains at least one sublist
  expect_true(length(result) >= 1)
  
  # Check that each sublist contains "coordinates" and "colour" components
  expect_true(all(sapply(result, function(sublist) {
    "coordinates" %in% names(sublist) && "colour" %in% names(sublist)
  })))
  
  # Check that coordinates are dataframes with "x" and "y" columns
  expect_true(all(sapply(result, function(sublist) {
    is.data.frame(sublist$coordinates) &&
    all(c("x", "y") %in% names(sublist$coordinates))
  })))
})
