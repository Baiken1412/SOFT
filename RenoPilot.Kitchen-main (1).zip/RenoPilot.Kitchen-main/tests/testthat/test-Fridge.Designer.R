test_that("Fridge.Designer generates expected shapes and colors", {
  # Define a sample model for a top freezer fridge
  top_freezer_fridge_model <- list(
    x = 30,
    y = 40,
    width = 200,
    height = 300,
    specifications = list(type = "Top Freezer", finish = "Matte Black")
  )

  # Call the Fridge.Designer function with the sample model
  top_freezer_fridge_shapes <- Fridge.Designer(top_freezer_fridge_model)

  # Check if top_freezer_fridge_shapes is a list
  expect_type(top_freezer_fridge_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a top freezer fridge
  expect_length(top_freezer_fridge_shapes, 3)

  # Check the properties of the shapes
  for (shape_entry in top_freezer_fridge_shapes) {
    expect_type(shape_entry, "list")
    expect_named(shape_entry, c("coordinates", "colour"))
    expect_type(shape_entry$coordinates, "list")
    expect_type(shape_entry$colour, "character")
  }

  # Define another sample model for a side by side fridge
  side_by_side_fridge_model <- list(
    x = 50,
    y = 60,
    width = 250,
    height = 350,
    specifications = list(type = "Side by Side", finish = "Stainless Steel")
  )

  # Call the Fridge.Designer function with the side by side fridge model
  side_by_side_fridge_shapes <- Fridge.Designer(side_by_side_fridge_model)

  # Check if side_by_side_fridge_shapes is a list
  expect_type(side_by_side_fridge_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a side by side fridge
  expect_length(side_by_side_fridge_shapes, 4)

  # Check the properties of the shapes
  for (shape_entry in side_by_side_fridge_shapes) {
    expect_type(shape_entry, "list")
    expect_named(shape_entry, c("coordinates", "colour"))
    expect_type(shape_entry$coordinates, "list")
    expect_type(shape_entry$colour, "character")
  }
})
