# Define a test for the 'polarToCartesian' service
test_that("polarToCartesian converts polar coordinates to Cartesian coordinates", {
  
  # Create a mock coordinates object (angle and radius)
  coordinates <- data.frame(
    angle = c(0, 45, 90, 135, 180, 225, 270, 315),
    radius = c(1, 2, 3, 4, 5, 6, 7, 8)
  )
  
  # Call the polarToCartesian service
  result <- Geometry.Converter()$polarToCartesian(coordinates)
  
  # Define the expected Cartesian coordinates
  expected <- data.frame(
    x = c(1.0, 1.1, -1.3, -4.0, -3.0, 2.2, 6.9, 5.3),
    y = c(0.0, 1.7, 2.7, 0.4, -4.0, -5.6, -1.2, 6.0)
  )
  
  # Check if the result matches the expected coordinates (within a small tolerance)
  expect_identical(result$x, expected$x, tolerance = 1e-2)
  expect_identical(result$y, expected$y, tolerance = 1e-2)
})
