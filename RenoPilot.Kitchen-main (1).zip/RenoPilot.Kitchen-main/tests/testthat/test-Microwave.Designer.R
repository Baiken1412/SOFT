# Define a test case for Microwave.Designer
test_that("Microwave.Designer generates expected shapes and colors", {
  # Define a sample model for a floor microwave
  floor_microwave_model <- list(
    x = 30,
    y = 40,
    width = 200,
    height = 300,
    specifications = list(type = "Floor", finish = "Stainless Steel")
  )

  # Call the Microwave.Designer function with the sample model
  floor_microwave_shapes <- Microwave.Designer(floor_microwave_model)

  # Check if floor_microwave_shapes is a list
  expect_type(floor_microwave_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a floor microwave
  expect_length(floor_microwave_shapes, 13)

  # Check the properties of the shapes
  for (shape_entry in floor_microwave_shapes) {
    expect_type(shape_entry, "list")
    expect_named(shape_entry, c("coordinates", "colour"))
    expect_type(shape_entry$coordinates, "list")
    expect_type(shape_entry$colour, "character")
  }

  # Define another sample model for a wall-mounted microwave
  wall_microwave_model <- list(
    x = 50,
    y = 60,
    width = 250,
    height = 350,
    specifications = list(type = "Wall Mounted", finish = "Crimson")
  )

  # Call the Microwave.Designer function with the wall-mounted microwave model
  wall_microwave_shapes <- Microwave.Designer(wall_microwave_model)

  # Check if wall_microwave_shapes is a list
  expect_type(wall_microwave_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a wall-mounted microwave
  expect_length(wall_microwave_shapes, 4)

  # Check the properties of the shapes
  for (shape_entry in wall_microwave_shapes) {
    expect_type(shape_entry, "list")
    expect_named(shape_entry, c("coordinates", "colour"))
    expect_type(shape_entry$coordinates, "list")
    expect_type(shape_entry$colour, "character")
  }
})
