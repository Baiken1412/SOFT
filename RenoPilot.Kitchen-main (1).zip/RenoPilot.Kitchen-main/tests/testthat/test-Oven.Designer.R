test_that("Oven.Designer generates expected shapes and colors", {
  # Define a sample model for a Single Door with Cooktop oven
  single_door_model <- list(
    x = 100,
    y = 100,
    width = 200,
    height = 400,
    specifications = list(type = "Single Door with Cooktop", finish = "Silver")
  )

  # Call the Oven.Designer function with the sample model
  oven_shapes <- Oven.Designer(single_door_model)

  # Check if oven_shapes is a list
  expect_type(oven_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a Single Door with Cooktop oven
  expect_length(oven_shapes, 7)

  # Check the properties of the first shape (oven)
  expect_type(oven_shapes[[1]], "list")
  expect_named(oven_shapes[[1]], c("coordinates", "colour"))
  expect_type(oven_shapes[[1]]$coordinates, "list")
  expect_equal(dim(oven_shapes[[1]]$coordinates), c(5, 2))  # Check if the oven shape has 5 coordinates (rows) and 2 columns (x, y)


  # Define a sample model for a Wall Mounted Double Door oven
  double_door_model <- list(
    x = 200,
    y = 200,
    width = 250,
    height = 500,
    specifications = list(type = "Wall Mounted Double Door", finish = "Black")
  )

  # Call the Oven.Designer function with the sample model
  oven_shapes_double_door <- Oven.Designer(double_door_model)

  # Check if oven_shapes_double_door is a list
  expect_type(oven_shapes_double_door, "list")

  # Check if the list contains the expected number of shape/color entries for a Wall Mounted Double Door oven
  expect_length(oven_shapes_double_door, 6)

  # Check the properties of the first shape (oven)
  expect_type(oven_shapes_double_door[[1]], "list")
  expect_named(oven_shapes_double_door[[1]], c("coordinates", "colour"))
  expect_type(oven_shapes_double_door[[1]]$coordinates, "list")
  expect_equal(dim(oven_shapes_double_door[[1]]$coordinates), c(5, 2))  # Check if the oven shape has 5 coordinates (rows) and 2 columns (x, y)

})
