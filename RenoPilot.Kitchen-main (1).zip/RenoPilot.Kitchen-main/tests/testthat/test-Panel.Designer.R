# Define a test case for Panel.Designer
test_that("Panel.Designer generates expected shape and color", {
  # Define a sample model for a panel
  panel_model <- list(
    x = 30,
    y = 40,
    width = 200,
    height = 300,
    specifications = list(finish = "Oyster Grey Matt")
  )

  # Call the Panel.Designer function with the sample model
  panel_shapes <- Panel.Designer(panel_model)

  # Check if panel_shapes is a list
  expect_type(panel_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a panel
  expect_length(panel_shapes, 1)

  # Check the properties of the shape (doorPanel)
  expect_type(panel_shapes[[1]], "list")
  expect_named(panel_shapes[[1]], c("coordinates", "colour"))
  expect_type(panel_shapes[[1]]$coordinates, "list")
  expect_equal(dim(panel_shapes[[1]]$coordinates), c(5, 2))  # Check if the doorPanel shape has 5 coordinates (rows) and 2 columns (x, y)
  expect_equal(panel_shapes[[1]]$colour, "#d6d4cb")

  # Define another sample model for a panel with a different finish
  panel_model2 <- list(
    x = 50,
    y = 60,
    width = 250,
    height = 350,
    specifications = list(finish = "Black")
  )

  # Call the Panel.Designer function with the second sample model
  panel_shapes2 <- Panel.Designer(panel_model2)

  # Check if panel_shapes2 is a list
  expect_type(panel_shapes2, "list")

  # Check if the list contains the expected number of shape/color entries for a panel
  expect_length(panel_shapes2, 1)

  # Check the properties of the shape (doorPanel)
  expect_type(panel_shapes2[[1]], "list")
  expect_named(panel_shapes2[[1]], c("coordinates", "colour"))
  expect_type(panel_shapes2[[1]]$coordinates, "list")
  expect_equal(dim(panel_shapes2[[1]]$coordinates), c(5, 2))  # Check if the doorPanel shape has 5 coordinates (rows) and 2 columns (x, y)
  expect_equal(panel_shapes2[[1]]$colour, "#000000")
})
