# Define a test case for Pantry.Designer
test_that("Pantry.Designer generates expected shapes and colors", {
  # Define a sample model for a pantry
  pantry_model <- list(
    x = 50,
    y = 50,
    width = 200,
    height = 300,
    specifications = list(finish = "Amaro Matt")
  )

  # Call the Pantry.Designer function with the sample model
  pantry_shapes <- Pantry.Designer(pantry_model)

  # Check if pantry_shapes is a list
  expect_type(pantry_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a pantry
  expect_length(pantry_shapes, 2)

  # Check the properties of the first shape (pantry)
  expect_type(pantry_shapes[[1]], "list")
  expect_named(pantry_shapes[[1]], c("coordinates", "colour"))
  expect_type(pantry_shapes[[1]]$coordinates, "list")
  expect_equal(dim(pantry_shapes[[1]]$coordinates), c(5, 2))  # Check if the pantry shape has 5 coordinates (rows) and 2 columns (x, y)
  expect_equal(pantry_shapes[[1]]$colour, "#dbd8ca")

  # Check the properties of the second shape (pantryKnob)
  expect_type(pantry_shapes[[2]], "list")
  expect_named(pantry_shapes[[2]], c("coordinates", "colour"))
  expect_type(pantry_shapes[[2]]$coordinates, "list")
  expect_equal(dim(pantry_shapes[[2]]$coordinates), c(5, 2))  # Check if the pantryKnob shape has 5 coordinates (rows) and 2 columns (x, y)
  expect_equal(pantry_shapes[[2]]$colour, "#000000")

  # Define another sample model for a pantry with a different finish
  pantry_model2 <- list(
    x = 100,
    y = 100,
    width = 250,
    height = 350,
    specifications = list(finish = "Prime Oak Woodmatt")
  )

  # Call the Pantry.Designer function with the second sample model
  pantry_shapes2 <- Pantry.Designer(pantry_model2)

  # Check if pantry_shapes2 is a list
  expect_type(pantry_shapes2, "list")

  # Check if the list contains the expected number of shape/color entries for a pantry
  expect_length(pantry_shapes2, 2)

  # Check the properties of the first shape (pantry)
  expect_type(pantry_shapes2[[1]], "list")
  expect_named(pantry_shapes2[[1]], c("coordinates", "colour"))
  expect_type(pantry_shapes2[[1]]$coordinates, "list")
  expect_equal(dim(pantry_shapes2[[1]]$coordinates), c(5, 2))  # Check if the pantryKnob shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(pantry_shapes2[[1]]$colour, "#856d5a")

  # Check the properties of the second shape (pantryKnob)
  expect_type(pantry_shapes2[[2]], "list")
  expect_named(pantry_shapes2[[2]], c("coordinates", "colour"))
  expect_type(pantry_shapes2[[2]]$coordinates, "list")
  expect_equal(dim(pantry_shapes2[[2]]$coordinates), c(5, 2))  # Check if the pantryKnob shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(pantry_shapes2[[2]]$colour, "#000000")
})
