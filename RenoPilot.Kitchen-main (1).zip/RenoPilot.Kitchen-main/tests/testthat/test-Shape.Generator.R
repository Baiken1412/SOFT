generators <- Shape.Generator()

test_that("Rectangle generators generates correct output", {
  # Create a mock Shape.Generator object with only the Rectangle function for testing
  shape_generator <- list(
      generators = list(
      Rectangle = generators[['Rectangle']],
      Square = generators[['Square']]
    )
  )
  
  # Set specifications
  specifications <- list(width = 8, height = 6)
  
  # Call the Rectangle generator function and get the result
  result <- shape_generator$generators[['Rectangle']](specifications)
  
  # Define expected coordinates based on the specifications
  expected_x <- c(0, 8, 8, 0, 0)
  expected_y <- c(0, 0, 6, 6, 0)
  
  expect_equal(result$x, expected_x)
  expect_equal(result$y, expected_y)
})

test_that("generators[['Square']] generates correct output", {
  shape_generator <- list(
      generators = list(
      Square = generators[['Square']]
    )
  )
    
  specifications <- list(size = 5)
  result <- shape_generator$generators[['Square']](specifications)
  
  expected_x <- c(0, 5, 5, 0, 0)
  expected_y <- c(0, 0, 5, 5, 0)
  expect_equal(result$x, expected_x)
  expect_equal(result$y, expected_y)
})


test_that("generators[['Triangle']] generates correct output", {
  shape_generator <- list(
      generators = list(
      Square = generators[['Triangle']]
    )
  )
  specifications <- list(width = 8, height = 6)
  result <- generators[['Triangle']](specifications)
  
  expected_x <- c(0, 8, 4, 0)
  expected_y <- c(0, 0, 6, 0)
  
  expect_equal(result$x, expected_x)
  expect_equal(result$y, expected_y)
})

test_that("generators[['Trapezoid']] generates correct output", {
  shape_generator <- list(
      generators = list(
      Square = generators[['Trapezoid']]
    )
  )
  specifications <- list(bottom = 10, top = 6, height = 5)
  result <- generators[['Trapezoid']](specifications)
  
  expected_x <- c(0, 10, 8, 2, 0)
  expected_y <- c(0, 0, 5, 5, 0)
  
  expect_equal(result$x, expected_x)
  expect_equal(result$y, expected_y)
})

test_that("generators[['Circle']] generates correct output", {

  # Define mock Angle.Converter and Geometry.Converter objects if needed
  angle.converter <- list(degreesToRadians = function(degrees) return(degrees))
  geometry.converter <- list(polarToCartesian = function(polar) return(polar))
  
  # Create generators list with the Circle function
  generators <- list(Circle = generators[['Circle']])
  
  # Set specifications
  specifications <- list(radius = 5)
  
  # Call the Circle function and get the result
  result <- generators[['Circle']](specifications)
  
  # Define expected coordinates based on the specifications
  expected_x <- rep(5 * cos(seq(0, 360, 10) * pi / 180), times = 1)
  expected_y <- rep(5 * sin(seq(0, 360, 10) * pi / 180), times = 1)
  
  expect_equal(result$x, expected_x)
  expect_equal(result$y, expected_y)
})

# test_that("generators[['Segment']] generates correct output", {
#   # Define mock Angle.Converter and Geometry.Converter objects if needed
#   angle.converter <- list(degreesToRadians = function(degrees) return(degrees))
#   geometry.converter <- list(polarToCartesian = function(polar) return(polar))
  
#   # Define mock utility object if needed
#   utility <- list(translate = function(coordinates) return(coordinates))
  
#   # Create generators list with the Segment function
#   generators <- list(Segment = generators[['Segment']])
  
#   # Set specifications
#   specifications <- list(start = 0, end = 90, radius = 5)
  
#   # Call the Segment function and get the result
#   result <- generators[['Segment']](specifications)
  
#   # Define expected coordinates based on the specifications
#   expected_x <- c(10.000, 9.924, 9.698, 9.330, 8.830, 8.214, 7.500, 6.710, 5.868, 5.000)
#   expected_y <- c(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
  
#   expect_equal(result$x, expected_x)
#   expect_equal(result$y, expected_y)
# })
