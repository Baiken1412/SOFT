test_that("Tap.Designer generates expected shapes and colors", {
  # Define a sample model for a tap
  tap_model <- list(
    x = 50,
    y = 50,
    width = 150,
    height = 300,
    specifications = list(finish = "Brass")
  )

  # Call the Tap.Designer function with the sample model
  tap_shapes <- Tap.Designer(tap_model)

  # Check if tap_shapes is a list
  expect_type(tap_shapes, "list")

  # Check if the list contains the expected number of shape/color entries for a tap
  expect_length(tap_shapes, 3)

  # Check the properties of the first shape (doorPanel)
  expect_type(tap_shapes[[1]], "list")
  expect_named(tap_shapes[[1]], c("coordinates", "colour"))
  expect_type(tap_shapes[[1]]$coordinates, "list")
  expect_equal(dim(tap_shapes[[1]]$coordinates), c(5, 2))  # Check if the doorPanel shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(tap_shapes[[1]]$colour, "#D5CB87")

  # Check the properties of the second shape (squareKnob)
  expect_type(tap_shapes[[2]], "list")
  expect_named(tap_shapes[[2]], c("coordinates", "colour"))
  expect_type(tap_shapes[[2]]$coordinates, "list")
  expect_equal(dim(tap_shapes[[2]]$coordinates), c(5, 2))  # Check if the squareKnob shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(tap_shapes[[2]]$colour, "#D5CB87")

  # Check the properties of the third shape (squareKnob1)
  expect_type(tap_shapes[[3]], "list")
  expect_named(tap_shapes[[3]], c("coordinates", "colour"))
  expect_type(tap_shapes[[3]]$coordinates, "list")
  expect_equal(dim(tap_shapes[[3]]$coordinates), c(5, 2))  # Check if the squareKnob1 shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(tap_shapes[[3]]$colour, "#D5CB87")

  # Define another sample model for a tap with a different finish
  tap_model2 <- list(
    x = 100,
    y = 100,
    width = 200,
    height = 400,
    specifications = list(finish = "Stainless Steel")
  )

  # Call the Tap.Designer function with the second sample model
  tap_shapes2 <- Tap.Designer(tap_model2)

  # Check if tap_shapes2 is a list
  expect_type(tap_shapes2, "list")

  # Check if the list contains the expected number of shape/color entries for a tap
  expect_length(tap_shapes2, 3)

  # Check the properties of the first shape (doorPanel)
  expect_type(tap_shapes2[[1]], "list")
  expect_named(tap_shapes2[[1]], c("coordinates", "colour"))
  expect_type(tap_shapes2[[1]]$coordinates, "list")
  expect_equal(dim(tap_shapes2[[1]]$coordinates), c(5, 2))  # Check if the doorPanel shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(tap_shapes2[[1]]$colour, "#948E8E")

  # Check the properties of the second shape (squareKnob)
  expect_type(tap_shapes2[[2]], "list")
  expect_named(tap_shapes2[[2]], c("coordinates", "colour"))
  expect_type(tap_shapes2[[2]]$coordinates, "list")
  expect_equal(dim(tap_shapes2[[2]]$coordinates), c(5, 2))  # Check if the squareKnob shape has 4 coordinates (rows) and 2 columns (x, y)
  expect_equal(tap_shapes2[[2]]$colour, "#948E8E")

  # Check the properties of the third shape (squareKnob1)
  expect_type(tap_shapes2[[3]], "list")
  expect_named(tap_shapes2[[3]], c("coordinates", "colour"))
  expect_type(tap_shapes2[[3]]$coordinates, "list")
  expect_equal(dim(tap_shapes2[[3]]$coordinates), c(5, 2)) 
  expect_equal(tap_shapes2[[3]]$colour, "#948E8E")
})
