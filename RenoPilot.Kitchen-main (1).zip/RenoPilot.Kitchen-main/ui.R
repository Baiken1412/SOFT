source("R/UI.View.R")
library(shiny)

library(bslib)

# Add a theme to the output plot such as colour and fonts
theme <- bs_theme(
  bg = "#ffffff", fg = "#006B42", primary = "#80f077",
  base_font = font_google("Poppins"),
  code_font = font_google("Roboto")
)

# Display the main UI plot with all components
ui <- fluidPage(
  includeCSS("www/styles.css"),
  div(
    style = "text-align: center;",
    titlePanel("RenoPilot Kitchen Generator")
  ),
  fluidRow(
    plotOutput("plot"),
    UI.View("components")
  ),
  theme = theme,
)
